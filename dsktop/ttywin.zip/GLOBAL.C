			void try(void);			//	global function prototype
			try();					//	call global function
			clearEvent( event );
			break;

		case cmTrace:
			void trace(void);			//	global function prototype
			trace();						//	call global function
			clearEvent( event );
