/*
 * Copyright (c) 1991 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *	@(#)strstrea.h	2.1.5 (Berkeley) 1/4/92
 */

#ifndef _STRSTREAM_INC_
#define _STRSTREAM_INC_

#include <iostream.h>

class strstreambuf : public streambuf {

public:
        strstreambuf();
        strstreambuf(int _n);
        strstreambuf(void * (*a)(long), void (*f)(void*));
        strstreambuf(char *_s, int ,   char *_start=NULL);
        ~strstreambuf();

  void freeze(int = 1);
  char *str();
  virtual int doallocate();
  virtual int overflow(int);
  virtual int underflow();
  virtual streambuf *setbuf(char *, int);
  virtual streampos seekoff(streamoff, ios::seek_dir, int);

private:

  enum   {
    dynamic = 1,
    frozen = 2,
    unlimited = 4 };

  void * (*allocf)(long);
  void   (*freef)(void *);
  void   init(char *, int, char *);
  short  flags;
  int    next_alloc;
};

class strstreambase : public virtual ios {

public:

  strstreambuf* rdbuf();

protected:

      strstreambase(char *, int, char *);
      strstreambase();
      ~strstreambase();

private:

  strstreambuf buf;

};

inline strstreambuf* strstreambase::rdbuf() { return &this->buf; }

class istrstream : public strstreambase, public istream {

public:

      istrstream(char *);
      istrstream(char *, int);
      ~istrstream();
};

class ostrstream : public strstreambase, public ostream {

public:

      ostrstream();
      ostrstream(char *, int, int=ios::out);
      ~ostrstream();

  char *str();
  int  pcount();

};

inline char *ostrstream::str() { return strstreambase::rdbuf()->str(); }
inline int   ostrstream::pcount() { return strstreambase::rdbuf()->out_waiting(); }

class strstream : public strstreambase, public iostream {

public:

      strstream();
      strstream(char *, int _sz, int _m);
      ~strstream();

  char *str();

};

inline char *strstream::str() { return strstreambase::rdbuf()->str(); }

#endif

