// Dummy

#include <stdio.h>
//#include <locale.h>

#define _STATIC

//#define DEC_POINT _lconv.decimal_point[0] no locales...
#define DEC_POINT ','
// german dec. point

#define _HEX         1
#define _OCT         2
#define _NEG         4
#define _OFL         8

#define PF_LEFT	     0x0001	      /* justification */
#define PF_SIGN	     0x0002	      /* force leading PF_SIGN */
#define PF_SPACE     0x0004	      /* force leading PF_SPACE */
#define PF_HASH	     0x0008	      /* PF_HASH flag */
#define PF_NOPOINT   0x0010	      /* supress radix point */
#define PF_UPPER     0x0020	      /* PF_UPPER case type */
#define PF_IS_SIGNED 0x0040	      /* signed data-type */
#define PF_ZFLAG     0x0080	      /* format with 0 */
#define PF_HEX	     0x0100	      /* PF_HEX integer  */
#define PF_OCT	     0x0200	      /* octal integer */
#define PF_GTYPE     0x0400	      /* g real type */
#define PF_EXP	     0x0800	      /* e real type */
#define PF_PSET	     0x1000	      /* precison set */
#define PF_LDMOD     0x2000	      /* long real */
#define PF_CPP       0x4000	      /* C++ formatting rules */


