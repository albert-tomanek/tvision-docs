#define Uses_TListViewer
#include <tv.h>

const char * const near TListViewer::name = "TListViewer";

