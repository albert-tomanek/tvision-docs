#define Uses_TSortedListBox
#include <tv.h>

const char * const near TSortedListBox::name = "TSortedListBox";
