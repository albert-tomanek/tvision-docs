#define Uses_TFrame
#include <tv.h>

const char * const near TFrame::name = "TFrame";

