#define Uses_TCheckBoxes
#include <tv.h>

const char * const near TCheckBoxes::name = "TCheckBoxes";

