#define Uses_TScrollBar
#include <tv.h>

const char * const near TScrollBar::name = "TScrollBar";

