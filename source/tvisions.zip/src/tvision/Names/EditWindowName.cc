#define Uses_TEditWindow
#include <tv.h>

const char * const near TEditWindow::name = "TEditWindow";
