#define Uses_TStaticText
#include <tv.h>

const char * const near TStaticText::name = "TStaticText";

