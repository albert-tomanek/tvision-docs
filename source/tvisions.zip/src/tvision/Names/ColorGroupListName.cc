#define Uses_TColorGroupList
#include <tv.h>

const char * const near TColorGroupList::name = "TColorGroupList";
