#define Uses_TColorDisplay
#include <tv.h>

const char * const near TColorDisplay::name = "TColorDisplay";
