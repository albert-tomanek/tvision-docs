#define Uses_TListBox
#include <tv.h>

const char * const near TListBox::name = "TListBox";

