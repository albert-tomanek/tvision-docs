#define Uses_TDialog
#include <tv.h>

const char * const near TDialog::name = "TDialog";

