#define Uses_TDirCollection
#include <tv.h>

const char * const near TDirCollection::name = "TDirCollection";

