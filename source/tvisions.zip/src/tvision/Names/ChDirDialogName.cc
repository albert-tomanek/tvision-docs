#define Uses_TChDirDialog
#include <tv.h>

const char * const near TChDirDialog::name = "TChDirDialog";

