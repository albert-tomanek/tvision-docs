#define Uses_TFileCollection
#include <tv.h>

const char * const near TFileCollection::name = "TFileCollection";

