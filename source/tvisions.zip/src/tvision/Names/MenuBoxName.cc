#define Uses_TMenuBox
#include <tv.h>

const char * const near TMenuBox::name = "TMenuBox";

