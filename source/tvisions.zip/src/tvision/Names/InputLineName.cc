#define Uses_TInputLine
#include <tv.h>

const char * const near TInputLine::name = "TInputLine";
