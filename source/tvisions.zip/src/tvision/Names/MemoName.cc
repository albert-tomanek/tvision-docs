#define Uses_TMemo
#include <tv.h>

const char * const near TMemo::name = "TMemo";
