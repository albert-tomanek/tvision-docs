#define Uses_TResourceCollection
#include <tv.h>

const char * const near TResourceCollection::name = "TResourceCollection";

