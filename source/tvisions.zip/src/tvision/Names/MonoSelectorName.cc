#define Uses_TMonoSelector
#include <tv.h>

const char * const near TMonoSelector::name = "TMonoSelector";
