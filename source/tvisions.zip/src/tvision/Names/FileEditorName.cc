#define Uses_TFileEditor
#include <tv.h>

const char * const near TFileEditor::name = "TFileEditor";
