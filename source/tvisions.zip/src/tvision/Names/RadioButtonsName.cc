#define Uses_TRadioButtons
#include <tv.h>

const char * const near TRadioButtons::name = "TRadioButtons";

