#define Uses_TBackground
#include <tv.h>

const char * const near TBackground::name = "TBackground";

