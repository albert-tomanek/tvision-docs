#define Uses_TDeskTop
#include <tv.h>

const char * const near TDeskTop::name = "TDeskTop";

