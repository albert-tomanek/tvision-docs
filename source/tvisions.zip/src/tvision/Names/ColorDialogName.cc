#define Uses_TColorDialog
#include <tv.h>

const char * const near TColorDialog::name = "TColorDialog";
