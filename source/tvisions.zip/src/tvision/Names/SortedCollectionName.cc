#define Uses_TSortedCollection
#include <tv.h>

const char * const near TSortedCollection::name = "TSortedCollection";

