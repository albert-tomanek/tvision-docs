#define Uses_TIndicator
#include <tv.h>

const char * const near TIndicator::name = "TIndicator";
