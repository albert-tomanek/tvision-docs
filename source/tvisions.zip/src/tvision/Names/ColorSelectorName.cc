#define Uses_TColorSelector
#include <tv.h>

const char * const near TColorSelector::name = "TColorSelector";
