#define Uses_TMenuView
#include <tv.h>

const char * const near TMenuView::name = "TMenuView";

