#define Uses_TStatusLine
#include <tv.h>

const char * const near TStatusLine::name = "TStatusLine";

