#define Uses_TDirListBox
#include <tv.h>

const char * const near TDirListBox::name = "TDirListBox";

