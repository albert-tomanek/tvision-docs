#define Uses_TFileInputLine
#include <tv.h>

const char * const near TFileInputLine::name = "TFileInputLine";
