#define Uses_TStringList
#include <tv.h>

const char * const near TStringList::name = "TStringList";

