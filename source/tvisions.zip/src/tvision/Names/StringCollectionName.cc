#define Uses_TStringCollection
#include <tv.h>

const char * const near TStringCollection::name = "TStringCollection";

