#define Uses_TView
#include <tv.h>

const char * const near TView::name = "TView";
