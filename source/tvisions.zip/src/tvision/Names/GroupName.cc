#define Uses_TGroup
#include <tv.h>

const char * const near TGroup::name = "TGroup";

