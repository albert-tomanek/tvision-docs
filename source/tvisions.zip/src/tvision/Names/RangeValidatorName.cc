#define Uses_TRangeValidator
#include <tv.h>

const char * const TRangeValidator::name = "TRangeValidator";

