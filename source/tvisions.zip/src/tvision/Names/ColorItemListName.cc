#define Uses_TColorItemList
#include <tv.h>

const char * const near TColorItemList::name = "TColorItemList";
