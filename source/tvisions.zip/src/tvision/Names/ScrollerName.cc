#define Uses_TScroller
#include <tv.h>

const char * const near TScroller::name = "TScroller";

