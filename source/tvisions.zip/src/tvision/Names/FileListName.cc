#define Uses_TFileList
#include <tv.h>

const char * const near TFileList::name = "TFileList";

