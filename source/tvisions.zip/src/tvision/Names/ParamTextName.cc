#define Uses_TParamText
#include <tv.h>

const char * const near TParamText::name = "TParamText";

