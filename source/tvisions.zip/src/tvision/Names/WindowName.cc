#define Uses_TWindow
#include <tv.h>

const char * const near TWindow::name = "TWindow";

