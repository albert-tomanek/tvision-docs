#define Uses_TFileDialog
#include <tv.h>

const char * const near TFileDialog::name = "TFileDialog";

