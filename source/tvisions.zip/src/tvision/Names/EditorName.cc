#define Uses_TEditor
#include <tv.h>

const char * const near TEditor::name = "TEditor";
