#define Uses_TButton
#include <tv.h>

const char * const near TButton::name = "TButton";

