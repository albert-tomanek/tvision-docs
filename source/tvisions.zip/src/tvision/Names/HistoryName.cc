#define Uses_THistory
#include <tv.h>

const char * const near THistory::name = "THistory";

