#define Uses_TLabel
#include <tv.h>

const char * const near TLabel::name = "TLabel";

