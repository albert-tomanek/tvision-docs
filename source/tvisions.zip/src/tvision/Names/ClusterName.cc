#define Uses_TCluster
#include <tv.h>

const char * const near TCluster::name = "TCluster";

