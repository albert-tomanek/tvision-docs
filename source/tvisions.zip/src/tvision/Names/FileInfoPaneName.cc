#define Uses_TFileInfoPane
#include <tv.h>

const char * const near TFileInfoPane::name = "TFileInfoPane";
