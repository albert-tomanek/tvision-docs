#define Uses_TValidator
#include <tv.h>

const char * const TValidator::name = "TValidator";

