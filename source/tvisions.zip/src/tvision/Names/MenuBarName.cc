#define Uses_TMenuBar
#include <tv.h>

const char * const near TMenuBar::name = "TMenuBar";

