#define Uses_TCollection
#include <tv.h>

const char * const near TCollection::name = "TCollection";

