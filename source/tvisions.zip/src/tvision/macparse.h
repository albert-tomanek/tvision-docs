typedef union {
  unsigned short u;
  char name[256];
  char c;
} YYSTYPE;
#define	NUM	258
#define	ID	259
#define	MACROSTART	260
#define	MACROEND	261
#define	CHAR	262
#define	SEMI	263
#define	EQUAL	264
#define	INSERTTEXT	265
#define	LBRACE	266
#define	RBRACE	267
#define	COLON	268
#define	STRINGSTART	269
#define	STRINGEND	270


extern YYSTYPE yylval;
