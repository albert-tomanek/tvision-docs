#define Uses_TApplication
#define Uses_TDeskTop
#define Uses_TRect
#define Uses_TEditor
#define Uses_TEditWindow
#define Uses_TFileEditor
#define Uses_TFileDialog
#define Uses_TChDirDialog
#define Uses_fpstream
#define Uses_MsgBox
#define Uses_TScreen
#define Uses_TEditorApp

#include <tv.h>

#include <tvedit.h>
#ifndef __TURBOC__
#ifdef USE_MACROS
#include <tvedmac.h>
#endif
#endif
#include <stdio.h>
#include <libc/dosio.h>

//
// writeView() function ( writes a view object to a resource file )
//

static void writeView(TView *p, void *strm)
{
   fpstream *s = (fpstream *) strm;
   if (p != TProgram::deskTop->last || p != clipWindow)
      *s << p;
}

void saveDesktop()
{
#ifdef __TURBOC__
    fpstream *f = new fpstream("TVEDIT.DST", ios::out|ios::binary);
#else
    fpstream *f = new fpstream("TVEDIT.DST", ios::out|ios::bin);
#endif

    if( f )
	{
	TProgram::deskTop->forEach(::writeView, f);
	*f << 0;
	if( !f )
	    {
	    messageBox("Could not create TVDEMO.DST.", mfOKButton | mfError);
	    delete f;
	    ::remove("TVDEMO.DST");
	    return;
	    }
	}
    delete f;
}

//
// storeDesktop() function ( stores the Desktop in a resource file )
//

int main(int argc,char *argv[])
{
    int i;
    TEditorApp *editorApp;
    editorApp = new TEditorApp();
    for (i=1;i<argc;i++) editorApp->openEditor(argv[i],True);
    editorApp->run();
//    saveDesktop();
    delete editorApp;
    return 0;
}

