#include <dir.h>
#include <unistd.h>

int getcurdir(int,char *);

int getcurdir(int drive, char *buffer)
{
  if (!drive) getwd(buffer);
  else
  {
    int d = getdisk();
    setdisk(drive-1);
    getwd(buffer);
    setdisk(d);
  }
  strcpy(buffer,buffer+3);
  return 0;
}

#if !defined( DJGPP ) || ( DJGPP < 2 )

#include <io.h>

extern "C" long __filelength(int fhandle)
{
  long oldval;
  long retval;
  oldval = lseek(fhandle,0,1);
  if (oldval == -1L) return -1L;
  retval = lseek(fhandle,0,2);
  if (retval == -1L) return -1L;
  if (lseek(fhandle,oldval,0) == -1L) return -1L;
  return retval;
}

#endif
