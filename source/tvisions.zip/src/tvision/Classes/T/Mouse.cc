#define Uses_TEvent
#include <tv.h>

TMouse::TMouse()
{
    show();
}

TMouse::~TMouse()
{
    hide();
}


