#define Uses_opstream
#define Uses_ipstream
#define Uses_TSortedCollection
#include <tv.h>

void TSortedCollection::write( opstream& os )
{
    TCollection::write( os );
    os << (int)duplicates;
}

void *TSortedCollection::read( ipstream& is )
{
    TCollection::read( is );
    int temp;
    is >> temp;
    duplicates = Boolean(temp);
    return this;
}

TSortedCollection::TSortedCollection( StreamableInit ) :
    TCollection( streamableInit )
{
}
