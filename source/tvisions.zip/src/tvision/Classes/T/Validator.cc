#define Uses_ipstream
#define Uses_opstream
#define Uses_TValidator
#include <tv.h>
#include <string.h>
#include <limits.h>
#include <stdio.h>

TValidator::TValidator() : Status(0), Options(0)
{
}

Boolean TValidator::IsValid(const char *)
{
  return True;
}

Boolean TValidator::IsValidInput(char *,Boolean)
{
  return True;
}

ushort TValidator::Transfer(char *,void *,TVTransfer)
{
  return 0;
}

Boolean TValidator::Valid(const char *S)
{
  if (IsValid(S) == True) return True;
  Error();
  return False;
}

TValidator::TValidator(StreamableInit)
{
}

void TValidator::write(opstream & os)
{
  os << Status << Options;
}

void * TValidator::read(ipstream & is)
{
  is >> Status >> Options;
  return this;
}

