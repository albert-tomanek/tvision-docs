#define Uses_TObject
#include <tv.h>

TObject::~TObject()
{
}

void TObject::shutDown()
{
}
