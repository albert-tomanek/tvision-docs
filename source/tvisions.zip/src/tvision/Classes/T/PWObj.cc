#define Uses_TPWrittenObjects
#include <tv.h>

TPWObj::TPWObj( const void *adr, P_id_type id ) : address( adr ), ident( id )
{
}

