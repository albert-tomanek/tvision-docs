#define Uses_TPReadObjects
#include <tv.h>

#include <assert.h>

TPReadObjects::TPReadObjects() : TNSCollection( 5, 5 ), curId( 0 )
{
}

TPReadObjects::~TPReadObjects()
{
}

void TPReadObjects::registerObject( const void *adr )
{
    ccIndex loc = insert( (void *)adr );
    assert( (unsigned)loc == curId++ );   // to be sure that TNSCollection
                                // continues to work the way
                                // it does now...
}

const void *TPReadObjects::find( P_id_type id )
{
    return at( id );
}

