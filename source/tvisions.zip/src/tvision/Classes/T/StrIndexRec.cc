#define Uses_TStrIndexRec
#include <tv.h>

TStrIndexRec::TStrIndexRec() :
    count(0)
{
}

