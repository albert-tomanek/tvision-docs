#define Uses_pstream
#define Uses_iopstream
#include <tv.h>

iopstream::iopstream( streambuf * sb )
{
    pstream::init( sb );
}

iopstream::~iopstream()
{
}

iopstream::iopstream()
{
}

