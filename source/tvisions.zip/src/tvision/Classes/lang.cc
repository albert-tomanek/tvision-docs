#define Uses_TScreen
#define Uses_TRadioButtons
#define Uses_TMenuBox
#define Uses_TFrame
#define Uses_TIndicator
#define Uses_THistory
#define Uses_TColorSelector
#define Uses_TMonoSelector
#define Uses_TColorDialog
#define Uses_TInputLine
#define Uses_TStatusLine
#define Uses_TCheckBoxes
#define Uses_TScrollBar
#define Uses_TButton
#define Uses_TDirListBox
#define Uses_TFileEditor
#define Uses_TEditWindow
#define Uses_TFileList
#define Uses_TProgram
#define Uses_MsgBox
#define Uses_TChDirDialog
#define Uses_TFileDialog
#define Uses_TFileInfoPane
#define Uses_TDeskTop

#include <tv.h>

const char * near TMonoSelector::normal = "Normal";
const char * near TMonoSelector::highlight = "Highlight";
const char * near TMonoSelector::underline = "Underline";
const char * near TMonoSelector::inverse = "Inverse";

const char * near TColorDialog::colors = "Colors";
const char * near TColorDialog::groupText = "~G~roup";
const char * near TColorDialog::itemText = "~I~tem";
const char * near TColorDialog::forText = "~F~oreground";
const char * near TColorDialog::bakText = "~B~ackground";
const char * near TColorDialog::textText = "Text ";
const char * near TColorDialog::colorText = "Color";
const char * near TColorDialog::okText = "O~K~";
const char * near TColorDialog::cancelText = "Cancel";

const char * near TDirListBox::drives = "Drives";
const char * near TEditWindow::clipboardTitle = "Clipboard";
const char * near TEditWindow::untitled = "Untitled";

const char * near TFileList::tooManyFiles = "Too many files.";

const char * near TProgram::exitText = "~Alt-X~ Exit";

const char * near MsgBoxText::yesText = "~Y~es";
const char * near MsgBoxText::noText = "~N~o";
const char * near MsgBoxText::okText = "O~K~";
const char * near MsgBoxText::cancelText = "Cancel";
const char * near MsgBoxText::warningText = "Warning";
const char * near MsgBoxText::errorText = "Error";
const char * near MsgBoxText::informationText = "Information";
const char * near MsgBoxText::confirmText = "Confirm";

const char * near TChDirDialog::changeDirTitle = "Change Directory";
const char * near TChDirDialog::dirNameText = "Directory ~n~ame";
const char * near TChDirDialog::dirTreeText = "Directory ~t~ree";
const char * near TChDirDialog::okText = "O~K~";
const char * near TChDirDialog::chdirText = "~C~hdir";
const char * near TChDirDialog::revertText = "~R~evert";
const char * near TChDirDialog::helpText = "Help";
const char * near TChDirDialog::drivesText = "Drives";
const char * near TChDirDialog::invalidText = "Invalid directory";

const char * near TFileDialog::filesText = "~F~iles";
const char * near TFileDialog::openText = "~O~pen";
const char * near TFileDialog::okText = "O~K~";
const char * near TFileDialog::replaceText = "~R~eplace";
const char * near TFileDialog::clearText = "~C~lear";
const char * near TFileDialog::cancelText = "Cancel";
const char * near TFileDialog::helpText = "~H~elp";
const char * near TFileDialog::invalidDriveText = "Invalid drive or directory";
const char * near TFileDialog::invalidFileText = "Invalid file name.";

const char * const near TFileInfoPane::months[] =
    {
    "","Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec"
    };

