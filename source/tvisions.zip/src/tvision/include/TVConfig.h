#if ( __GNUC_MINOR__ < 7 )
#pragma interface
#endif

/***************************************************************/
/*                                                             */
/*  this header-file was modified by Robert Hoehne             */
/*  to use it with DJ's port of gcc                            */
/*                                                             */
/***************************************************************/


/* ------------------------------------------------------------------------*/
/*                                                                         */
/*   CONFIG.H                                                              */
/*                                                                         */
/*   Copyright (c) Borland International 1991                              */
/*   All Rights Reserved.                                                  */
/*                                                                         */
/*   miscellaneous system-wide configuration parameters                    */
/*   FOR INTERNAL USE ONLY                                                 */
/*                                                                         */
/* ------------------------------------------------------------------------*/

#if !defined( __CONFIG_H )
#define __CONFIG_H

#include <limits.h>

const eventQSize = 16;
const maxCollectionSize = UINT_MAX/sizeof( void * );

const maxViewWidth = 132;

const maxFindStrLen    = 80;
const maxReplaceStrLen = 80;

#define interrupt
#define huge
#define far
#define near
#define __LARGE__
#define FP_OFF(x) (int)(x)
#define _Cdecl
#define movmem(src,dst,size) memmove(dst,src,size)
#define heapcheck() 1
#define ltoa itoa
#define DIRSEPARATOR '/'
#define DIRSEPARATOR_ "/"
int getcurdir(int, char *);
extern "C" long __filelength(int);
#define filelength __filelength

#define USE_LFN 1
#define MAXLFN 256 /* length of a filename or ext */
#define MAXLFNPATH 512

#endif	// __CONFIG_H
