#include <dir.h>

unsigned short ffattrib(struct ffblk *ff)
{
  return ff->ff_attrib;
}

unsigned short ffdate(struct ffblk *ff)
{
  return ff->ff_fdate;
}

unsigned short fftime(struct ffblk *ff)
{
  return ff->ff_ftime;
}

unsigned long ffsize(struct ffblk *ff)
{
  return ff->ff_fsize;
}

char * ffname(struct ffblk *ff)
{
  return ff->ff_name;
}

