#define Uses_TFrame
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RFrame( TFrame::name,
                         TFrame::build,
                         __DELTA(TFrame)       
                       );

