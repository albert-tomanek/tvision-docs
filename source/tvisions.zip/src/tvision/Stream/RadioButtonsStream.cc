#define Uses_TRadioButtons
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RRadioButtons( TRadioButtons::name,
                                TRadioButtons::build,
                                __DELTA(TRadioButtons)
                              );

