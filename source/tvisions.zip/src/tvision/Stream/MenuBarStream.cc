#define Uses_TMenuBar
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RMenuBar( TMenuBar::name,
                           TMenuBar::build,
                           __DELTA(TMenuBar)
                         );

