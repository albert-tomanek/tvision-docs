#define Uses_TDirCollection
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass RDirCollection( TDirCollection::name,
                                 TDirCollection::build,
                                 __DELTA(TDirCollection) 
                               );

