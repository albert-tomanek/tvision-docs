#define YYDEBUG 1
int CompileMacros(char *);
void DeCompileMacros(char *);
#define UNKNOWN_IDENTIFER	1
#define UNKNOWN_MACRO		2
