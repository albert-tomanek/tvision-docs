#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int mv_files(const char *from,const char *to)
{
  return rename(from,to);
}

int mv_to_dir(int argc,char *argv[])
{
  char *dist,*tmp,*tmp1,*temp,*dir=argv[argc-1];
  int dl=strlen(dir);
  int i;
  for (i=1;i<argc-1;i++)
  {
    temp = argv[i];
    tmp = strrchr(temp,'/');
    tmp1 = strrchr(temp,'\\');
    if (!tmp && !tmp1) tmp = temp;
    else if (!tmp) tmp = tmp1+1;
    else if (!tmp1) tmp++;
    else tmp = (tmp < tmp1) ? tmp1+1 : tmp+1;
    dist = (char *)malloc(dl+strlen(tmp)+2);
    strcpy(dist,dir);
    strcat(dist,"/");
    strcat(dist,tmp);
    mv_files(temp,dist);
    free(dist);
  }
  return 0;
}

int main(int argc,char *argv[])
{
  struct stat statbuf;
  if (argc<3) return (-1);
  if (argc>3) return mv_to_dir(argc,argv);
  if (stat(argv[2],&statbuf) != 0) return mv_files(argv[1],argv[2]);
  if (statbuf.st_mode & S_IFDIR) return mv_to_dir(argc,argv);
  return mv_files(argv[1],argv[2]);
}
