#if ( __GNUC_MINOR__ < 7 )

#define Uses_EventCodes
#define Uses_MsgBox
#define Uses_TApplication
#define Uses_TBackground
#define Uses_TButton
#define Uses_TChDirDialog
#define Uses_TCheckBoxes
#define Uses_TCluster
#define Uses_TCollection
#define Uses_TColorDialog
#define Uses_TColorDisplay
#define Uses_TColorGroup
#define Uses_TColorGroupList
#define Uses_TColorItem
#define Uses_TColorItemList
#define Uses_TColorSelector
#define Uses_TCommandSet
#define Uses_TCrossRef
#define Uses_TDeskTop
#define Uses_TDialog
#define Uses_TDirCollection
#define Uses_TDirEntry
#define Uses_TDirListBox
#define Uses_TDrawBuffer
#define Uses_TEditWindow
#define Uses_TEditor
#define Uses_TEvent
#define Uses_TEventQueue
#define Uses_TFileCollection
#define Uses_TFileDialog
#define Uses_TFileEditor
#define Uses_TFileInfoPane
#define Uses_TFileInputLine
#define Uses_TFileList
#define Uses_TFilterValidator
#define Uses_TFindDialogRec
#define Uses_TFrame
#define Uses_TGroup
#define Uses_THistory
#define Uses_THistoryViewer
#define Uses_THistoryWindow
#define Uses_THelpFile
#define Uses_THelpIndex
#define Uses_THelpTopic
#define Uses_THelpViewer
#define Uses_THelpWindow
#define Uses_TIndicator
#define Uses_TInputLine
#define Uses_TKeys
#define Uses_TLabel
#define Uses_TListBox
#define Uses_TListViewer
#define Uses_TMemo
#define Uses_TMenu
#define Uses_TMenuBar
#define Uses_TMenuBox
#define Uses_TMenuItem
#define Uses_TMenuView
#define Uses_TMonoSelector
#define Uses_TNSCollection
#define Uses_TNSSortedCollection
#define Uses_TObject
#define Uses_TPReadObjects
#define Uses_TPWrittenObjects
#define Uses_TPalette
#define Uses_TParagraph
#define Uses_TParamText
#define Uses_TPoint
#define Uses_TProgram
#define Uses_TRadioButtons
#define Uses_TRangeValidator
#define Uses_TRect
#define Uses_TReplaceDialogRec
#define Uses_TResourceCollection
#define Uses_TResourceFile
#define Uses_TResourceItem
#define Uses_TSItem
#define Uses_TScreen
#define Uses_TScrollBar
#define Uses_TScroller
#define Uses_TSearchRec
#define Uses_TSortedCollection
#define Uses_TSortedListBox
#define Uses_TStaticText
#define Uses_TStaticText
#define Uses_TStatusDef
#define Uses_TStatusItem
#define Uses_TStatusLine
#define Uses_TStrIndexRec
#define Uses_TStrListMaker
#define Uses_TStreamable
#define Uses_TStreamableClass
#define Uses_TStreamableTypes
#define Uses_TStringCollection
#define Uses_TStringList
#define Uses_TSubMenu
#define Uses_TSystemError
#define Uses_TTerminal
#define Uses_TTextDevice
#define Uses_TValidator
#define Uses_TView
#define Uses_TWindow
#define Uses_ViewCommands
#define Uses_fpbase
#define Uses_fpstream
#define Uses_ifpstream
#define Uses_iopstream
#define Uses_ipstream
#define Uses_ofpstream
#define Uses_opstream
#define Uses_otstream
#define Uses_pstream
#define Uses_TFileViewer

#pragma implementation "help.h"
#pragma implementation "helpbase.h"
#pragma implementation "Config.h"
#pragma implementation "TTypes.h"
#pragma implementation "TKeys.h"
#pragma implementation "Util.h"
#pragma implementation "TVObjs.h"
#pragma implementation "TObjStrm.h"
#pragma implementation "DrawBuf.h"
#pragma implementation "Objects.h"
#pragma implementation "Validate.h"
#pragma implementation "System.h"
#pragma implementation "MsgBox.h"
#pragma implementation "Resource.h"
#pragma implementation "Views.h"
#pragma implementation "Dialogs.h"
#pragma implementation "Stddlg.h"
#pragma implementation "Colorsel.h"
#pragma implementation "Menus.h"
#pragma implementation "TextView.h"
#pragma implementation "Editors.h"
#pragma implementation "App.h"
#pragma implementation "stdapp.h"
#pragma implementation "tvedcons.h"
#pragma implementation "tvedit.h"
#pragma implementation "tvedmac.h"
#pragma implementation "FileView.h"

#include <tv.h>
#include <help.h>
#include <tvedcons.h>
#include <tvedit.h>
#include <tvedmac.h>

#endif
