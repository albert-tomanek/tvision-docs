/* delempty.c: delete all empty files in a given directory */
/* (GVISION)                                               */

#include <dos.h>
#include <dir.h>
#include <stdio.h>
#include <stdlib.h>

main(int argc, char *argv[])
{
 struct ffblk entry;
 int done;
 char curdir[MAXPATH];

 *curdir = '\\';
 getcurdir(0, curdir+1);
 if (chdir(argv[1]))
  {
   fputs("delempty: illegal directory\n", stderr);
   exit(1);
  }

 done = findfirst("*.*", &entry, 0);
 while (!done)
  {
    if (!entry.ff_fsize)
     unlink(entry.ff_name);
    done = findnext(&entry);
  }

 chdir(curdir);
 return 0;
}