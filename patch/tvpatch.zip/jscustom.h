#ifndef __JSCUSTOM_H__
#define __JSCUSTOM_H__

/*********************************************************/
/*                                                       */
/* JSCUSTOM.H                                            */
/*                                                       */
/* Custom TV Extensions by J�rn Sierwald                 */
/*                                                       */
/* Last Change 30.3.94                                   */
/*                                                       */
/*********************************************************/

// TJSList is a normal Browser

class TJSList : public TScroller {
public:

    TJSList( const TRect& bounds, TScrollBar *aHScrollBar,
      TScrollBar *aVScrollBar, int entries);
    ~TJSList();

    void draw();
    void handleEvent(TEvent& event);
    TPalette& getPalette() const;

    virtual void fillLine( TDrawBuffer& b, int line, ushort color ) = 0;
    virtual void setSelected( long int );
    virtual void setEntries( long int );

    long int selected;
    long int entries;
};

// TInteger displays an int value

class TInteger : public TView {
public:
  TInteger( const TRect& bounds);
  ~TInteger();

  size_t dataSize() {return sizeof(value);};
  void draw();
  void getData( void *rec ) { *(int*)rec = value; };
  TPalette& getPalette() const;
  void setData( void *rec ) { value= *(int*)rec; drawView(); };

  int value;
};

#endif

