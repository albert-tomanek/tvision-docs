// Threads.cpp
//
// This file is for DOS only.
// The functions are never called, they just make the linker shut up.

#if !defined(__MT__)
extern "C" int
_beginthread (void (*start)(void *arg), void *stack, unsigned stack_size, void *arg_list)
{return 0;};

extern "C" void
_endthread (void)
{};
#endif

