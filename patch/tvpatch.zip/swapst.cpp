#define Uses_TSystemError
#include <tv.h>

void TSystemError::swapStatusLine( TDrawBuffer& buf ) {

};

