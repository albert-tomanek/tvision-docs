/******************************************************/
/* patches.h                                          */
/*                                                    */
/* part of 'Turbo Vision for OS/2'                    */
/*                                                    */
/* Copyright 1993 J�rn Sierwald                       */
/******************************************************/

#ifndef __patches_h
#define __patches_h

// german text strings TVTEXT1,TVTEXT2,HELP
#define __TV_GER__
// #define __TV_ENG__

#ifdef __EMX__
#  define __TV4EMX__
#endif

#ifdef __IBMCPP__
#  define __TV4ICC__
#endif

#ifdef __BORLANDC__
#  define __TV4BCC__
#endif

#ifdef GO32
#  define __TV4DJ__
#endif

#if ( defined(__TV4EMX__) || defined(__TV4ICC__) || defined(__TV4BCC__) )
#  define __TV4OS2__
#endif

#ifdef __WATCOMC__
#  define __TV4WATCOM__
#  ifdef __DOS__
#    define __TV4WATCOMDOS__
#  else
#    define __TV4WATCOMOS2__
#    define __TV4OS2__
#  endif
#endif

#include <stdlib.h>
#include <assert.h>
#include <limits.h>

#ifdef __TV4EMX__
#  include <memory.h>
#endif

#if defined(__TV4TS__) || defined(__TV4WATCOMDOS__) || defined(__TV4DJ__)
#  include <dos.h>
#endif

#ifdef __TV4WATCOMOS2__
#  include <process.h>
#endif

#if 0
// The TV files are full of far and near modifiers
// I'm too lazy to change all declarations...
#ifndef __TV4WATCOMDOS__
#define far
#define near
#define huge
#endif
#endif

#define _FAR

/******************************************************/
/* Compiler dependent functions                       */
/******************************************************/

#if defined( __TV4EMX__ ) || defined (__TV4BCC__) || defined(__TV4WATCOM__) || defined(__TV4DJ__)
#  ifndef max
#  define max(a,b) ((a)>(b) ? (a) : (b))
#  endif
#  ifndef min
#  define min(a,b) ((a)>(b) ? (b) : (a))
#  endif
#endif

#ifdef __TV4EMX__
inline  char * ltoa (long value, char *string, int radix) {
  return _ltoa(value, string, radix);
};
inline  char * itoa (int value, char *string, int radix) {
  return _itoa(value,string,radix);
};
 
#endif

#ifdef __TV4EMX__
#  define EMX_SWITCH_1 if(_osmode==OS2_MODE) {
#  define EMX_SWITCH_2 };
#  define EMX_SWITCH_3 if(_osmode!=OS2_MODE) {
#else
#  define EMX_SWITCH_1
#  define EMX_SWITCH_2
#  define EMX_SWITCH_3
#endif

#ifdef __TV4WATCOMOS2__
#  define _Optlink
#endif

#ifdef __TV4DJ__
// merely a prototype. ltoa is defined in the iostream lib....
char *ltoa(long value,char *string, int radix);

#include <dpmi.h>
extern _go32_dpmi_registers mouseIntRegs;
#endif

/******************************************************/
/* Filesystems                                        */
/******************************************************/

#define TV_MAXPATH 260
#define TV_MAXDRIVE 3
#define TV_MAXEXT 260

#if 0
#define MAXPATH 260
#define MAXPATHLEN 260

#ifndef __TV4BCC__
#define MAXDRIVE  3
#if 0
#define MAXDIR    256
#define MAXFILE   9
#define MAXEXT    5
#endif
#endif
#endif

#if defined(__TV4TS__) || defined(__TV4EMX__) || defined(__TV4WATCOMDOS__) || defined(__TV4DJ__)
  #define OS_WILDCARDS "*.*"
#else
  #define OS_WILDCARDS "*"
#endif

#if defined(__TV4TS__)
#  define FILE_DIRECTORY FA_DIREC
#endif
#if defined(__TV4WATCOMDOS__)
#  define FILE_DIRECTORY _A_SUBDIR
#  define FILE_READONLY  _A_RDONLY
#  define FILE_ARCHIVED  _A_ARCH
#endif

#if defined(__TV4DJ__)
#  include <dir.h>
#  define FILE_DIRECTORY FA_DIREC
#  define FILE_ARCHIVED FA_ARCH
#  define FILE_READONLY FA_RDONLY
#endif

#if 0
#ifndef __TV4BCC__
#define _Cdecl
#endif
#endif

#define WILDCARDS 0x01
#define EXTENSION 0x02
#define FILENAME  0x04
#define DIRECTORY 0x08
#define DRIVE     0x10

#if defined(__TV4EMX__) || defined(__TV4ICC__) || defined(__TV4WATCOM__)
struct  ftime   {
    unsigned    ft_tsec  : 5;   /* Two second interval */
    unsigned    ft_min   : 6;   /* Minutes */
    unsigned    ft_hour  : 5;   /* Hours */
    unsigned    ft_day   : 5;   /* Days */
    unsigned    ft_month : 4;   /* Months */
    unsigned    ft_year  : 7;   /* Year */
};

int fnsplit(const char *__path,
                            char *__drive,
                            char *__dir,
                            char *__name,
                            char *__ext);

void fnmerge(char *__path,
                            const char *__drive,
                            const char *__dir,
                            const char *__name,
                            const char *__ext);
int getdisk(void);
int getcurdir(int __drive, char *__directory);

#endif

#if defined(__TV4DJ__)

long filelength(int file);
int getcurdir(int __drive, char *__directory);

#endif

/******************************************************/
/* Hardware access                                    */
/******************************************************/

unsigned long getTicks();
// returns a value that can be used as a substitute for the DOS Ticker at [0040:006C]
unsigned char getShiftState();
// returns a value that can be used as a substitute for the shift state at [0040:0017]

#endif

