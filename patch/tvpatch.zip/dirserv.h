// Dirserv.h
//
// Portable Directory Services

#ifndef __DIRSERV_H
#define __DIRSERV_H

#if defined(__TV4BCC__) || defined(__TV4TS__)
  #if !defined( __DIR_H )
  #include <Dir.h>
  #endif  // __DIR_H
#endif

#if defined(__TV4TS__) || defined(__TV4BCC__)
  #if !defined( __DOS_H )
  #include <Dos.h>
  #endif  // __DOS_H
#endif

#if defined(__TV4OS2__) && !defined(__TV4BCC__)
#define INCL_DOSFILEMGR
#include <os2.h>
#endif

#ifdef __TV4EMX__
#include <sys/types.h>
#include <dirent.h>
#include <sys/emx.h>
#endif

class DirService {
public:
  DirService();
  ~DirService();

  int findfirst( const char* path, unsigned long attr, TSearchRec& searchRec );
  int findnext( TSearchRec& searchRec );
private:

  int used;

#if defined (__TV4TS__)
  find_t s;
#endif

#if defined (__TV4WATCOMDOS__)
  find_t s;
#endif

#if defined(__TV4BCC__) || defined(__TV4DJ__)
  ffblk s;
#endif

#if defined (__TV4ICC__) || defined(__TV4WATCOMOS2__)
  HDIR hdir;
#endif

#if defined (__TV4EMX__)
  struct _find find;
#endif

};

#endif

