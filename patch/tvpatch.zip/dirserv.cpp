// dirserv.cpp
// Portable directory services

#define Uses_DirService
#include <tv.h>

#if !defined( __ERRNO_H )
#include <Errno.h>
#endif  // __ERRNO_H

#if !defined( __IO_H )
#include <IO.h>
#endif  // __IO_H

#if !defined( __STDIO_H )
#include <Stdio.h>
#endif  // __STDIO_H

#if !defined( __CTYPE_H )
#include <ctype.h>
#endif  // __CTYPE_H

#if !defined( __ASSERT_H )
#include <Assert.h>
#endif  // __ASSERT_H

#if defined(__TV4TS__) || defined(__TV4BCC__)
  #if !defined( __DOS_H )
  #include <Dos.h>
  #endif  // __DOS_H
#endif

#if !defined( __STRING_H )
#include <String.h>
#endif  // __STRING_H

/*
struct TSearchRec
{
    unsigned long attr;
    unsigned char hours, minutes, seconds;
    unsigned char year, month, day;
    long size;
    char name[TV_MAXPATH]; // long filename
};
*/

DirService::DirService() {
  used=0;
};

DirService::~DirService() {
  if (used) {
#if defined (__TV4ICC__) || defined(__TV4WATCOMOS2__)
    DosFindClose(hdir);
#endif
  };
};

#define DirCopy \
  ftime t; \
  unsigned long t2 = ((unsigned long)(unsigned short) s.wr_time)+((unsigned long)(unsigned short) s.wr_date)*0x10000; \
  memcpy(&t,&t2,4); \
  searchRec.seconds = t.ft_tsec*2; \
  searchRec.minutes = t.ft_min; \
  searchRec.hours   = t.ft_hour; \
  searchRec.day     = t.ft_day; \
  searchRec.month   = t.ft_month; \
  searchRec.year    = t.ft_year; \
  searchRec.attr    = s.attrib; \
  searchRec.size    = s.size; \
  strcpy( searchRec.name, s.name );


DirService::findfirst( const char* path, unsigned long attr, TSearchRec& searchRec ) {

#if defined (__TV4BCCDOS__)
  int res = ::findfirst( path, &s, attr );
  DirCopy
  return res;
#endif

#if defined (__TV4WATCOMDOS__)
  int res = _dos_findfirst( path, attr, &s );
  DirCopy
  return res;
#endif

#if defined (__TV4BCC__) || defined (__TV4DJ__)
  int res = ::findfirst( path, &s, attr );
  ftime t;
  unsigned long t2 = ((unsigned long)(unsigned short) s.ff_ftime)+((unsigned long)(unsigned short) s.ff_fdate)*0x10000;
  memcpy(&t,&t2,4);
  searchRec.seconds = t.ft_tsec*2;
  searchRec.minutes = t.ft_min; 
  searchRec.hours   = t.ft_hour; 
  searchRec.day     = t.ft_day; 
  searchRec.month   = t.ft_month; 
  searchRec.year    = t.ft_year; 
  searchRec.attr    = s.ff_attrib; 
  searchRec.size    = s.ff_fsize; 
  strcpy( searchRec.name, s.ff_name );
  return res;
#endif

#if defined (__TV4ICC__) || defined(__TV4WATCOMOS2__)
  hdir = HDIR_CREATE;
  ULONG cFilenames = 1;
  FILEFINDBUF3 findbuf;
  APIRET res;
  res = DosFindFirst( path, &hdir, attr, &findbuf, sizeof(findbuf), &cFilenames, FIL_STANDARD);
  if (res==0) used=1;
  searchRec.seconds = findbuf.ftimeLastWrite.twosecs*2;
  searchRec.minutes = findbuf.ftimeLastWrite.minutes;
  searchRec.hours   = findbuf.ftimeLastWrite.hours;
  searchRec.day     = findbuf.fdateLastWrite.day;
  searchRec.month   = findbuf.fdateLastWrite.month;
  searchRec.year    = findbuf.fdateLastWrite.year;
  searchRec.attr    = findbuf.attrFile;
  searchRec.size    = findbuf.cbFile;
  strcpy( searchRec.name, findbuf.achName );
  return res;

#endif

#if defined (__TV4EMX__)
  int res;
  res = __findfirst( path, attr, &find );

  ftime t;
  unsigned long t2 = ((unsigned long)(unsigned short) find.time)+((unsigned long)(unsigned short) find.date)*0x10000;
  memcpy(&t,&t2,4);
  searchRec.seconds = t.ft_tsec*2;
  searchRec.minutes = t.ft_min;
  searchRec.hours   = t.ft_hour;
  searchRec.day     = t.ft_day;
  searchRec.month   = t.ft_month;
  searchRec.year    = t.ft_year;
  searchRec.attr    = find.attr;
  searchRec.size    = find.size_lo+(((unsigned long)find.size_hi) << 16);
  strcpy( searchRec.name, find.name );
  return res;
#endif
};

DirService::findnext( TSearchRec& searchRec ) {

#if defined (__TV4TS__)
  int res = ::findnext( &s );
  DirCopy
  return res;
#endif

#if defined (__TV4WATCOMDOS__)
  int res = _dos_findnext( &s );
  DirCopy
  return res;
#endif

#if defined(__TV4BCC__) || defined(__TV4DJ__)
  int res = ::findnext( &s );
  ftime t;
  unsigned long t2 = ((unsigned long)(unsigned short) s.ff_ftime)+((unsigned long)(unsigned short) s.ff_fdate)*0x10000;
  memcpy(&t,&t2,4);
  searchRec.seconds = t.ft_tsec*2;
  searchRec.minutes = t.ft_min;
  searchRec.hours   = t.ft_hour;
  searchRec.day     = t.ft_day;
  searchRec.month   = t.ft_month;
  searchRec.year    = t.ft_year;
  searchRec.attr    = s.ff_attrib;
  searchRec.size    = s.ff_fsize;
  strcpy( searchRec.name, s.ff_name );
  return res;
#endif

#if defined (__TV4ICC__) || defined(__TV4WATCOMOS2__)
  ULONG cFilenames = 1;
  FILEFINDBUF3 findbuf;
  APIRET res;
  res = DosFindNext( hdir, &findbuf, sizeof(findbuf), &cFilenames);
  searchRec.seconds = findbuf.ftimeLastWrite.twosecs*2;
  searchRec.minutes = findbuf.ftimeLastWrite.minutes;
  searchRec.hours   = findbuf.ftimeLastWrite.hours;
  searchRec.day     = findbuf.fdateLastWrite.day;
  searchRec.month   = findbuf.fdateLastWrite.month;
  searchRec.year    = findbuf.fdateLastWrite.year;
  searchRec.attr    = findbuf.attrFile;
  searchRec.size    = findbuf.cbFile;
  strcpy( searchRec.name, findbuf.achName );
  return res;
#endif

#if defined (__TV4EMX__)
  int res;
  res = __findnext(&find);

  ftime t;
  unsigned long t2 = ((unsigned long)(unsigned short) find.time)+((unsigned long)(unsigned short) find.date)*0x10000;
  memcpy(&t,&t2,4);
  searchRec.seconds = t.ft_tsec*2;
  searchRec.minutes = t.ft_min;
  searchRec.hours   = t.ft_hour;
  searchRec.day     = t.ft_day;
  searchRec.month   = t.ft_month;
  searchRec.year    = t.ft_year;
  searchRec.attr    = find.attr;
  searchRec.size    = find.size_lo+(((unsigned long)find.size_hi) << 16);
  strcpy( searchRec.name, find.name );
  return res;
#endif
};

