// TTPRVLNS.CPP
// Copyright 1994 by J�rn Sierwald
//
// C++ Version of ttprvlns.asm
// implementation of TTerminal::prevLines(...)
//
// "You don't need assembler to write obfuscated code."

#define Uses_TTerminal
#include <tv.h>

size_t TTerminal::prevLines( size_t pos, int lines ) {
  if (lines==0) { bufInc(pos); bufInc(pos); return pos; };
  // I don't see the logic in the previous line. But that's what
  // the .asm file says.

  if (pos==queBack) return queBack; // Nothing to do

  bufDec(pos); // pos might be pointing to a '\n'

  if (pos<queBack) {
    while ( !( buffer[pos]=='\n' && !--lines ) && pos-- );
    if (lines) pos=bufSize-1;
  };

  if (lines)
    while ( !( buffer[pos]=='\n' && !--lines ) && pos---queBack );

  if (lines)
    return queBack;
  else 
    bufInc(pos);

  return pos;
};

#if 0
    do {
      if (buffer[pos]==012) { if (!(--lines)) break; };
    } until (pos---queBack);
#endif

