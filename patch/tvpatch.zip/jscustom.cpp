/********************************************************************/
/* TJSList                                                          */
/********************************************************************/

#define Uses_TEvent
#define Uses_TKeys
#define Uses_JSCustom
#include <tv.h>
#include <strstrea.h>

TJSList::TJSList( const TRect& bounds, TScrollBar *aHScrollBar,
	      TScrollBar *aVScrollBar, int pEntries) :
       TScroller( bounds, aHScrollBar, aVScrollBar )
{
    options = options | ofFramed | ofFirstClick;
    entries = pEntries;
    setLimit( 0, entries );
    selected = 0;
}

TJSList::~TJSList() {
};

TPalette& TJSList::getPalette() const
{
  static TPalette palette( "\x07\x08\x14", 3);
  return palette;
};

void TJSList::handleEvent(TEvent& event)
{
  drawLock++; // no redraw
  switch (event.what)
  {
    case evKeyDown:
      switch (event.keyDown.keyCode)
      {
	case kbUp:
	  if (selected>0) selected--;
	  if (selected>=delta.y || delta.y==0) {
	    clearEvent(event);
	    drawFlag=True;
	  };
	  break;
	case kbDown:
	  if (selected+1<entries) selected++;
	  if (selected<delta.y+size.y || delta.y>=limit.y-size.y) {
	    clearEvent(event);
	    drawFlag=True;
	  };
	  break;
      };
    break;
  };

  TScroller::handleEvent(event);

  switch (event.what)
  {
    case evMouseDown:
    {
      TPoint local=makeLocal(event.mouse.where);
      int j = delta.y + local.y;       // delta is scroller offset
      if ( j<entries ) {
	selected=j;
	drawFlag=True;
      };
      clearEvent(event);
      break;
    };
    case evBroadcast:
      if (event.message.command == cmScrollBarChanged &&
	  ( event.message.infoPtr == hScrollBar ||
	    event.message.infoPtr == vScrollBar )
	)
      {
	if (selected<delta.y) selected=delta.y;
	if (selected>delta.y+size.y-1) selected=min(entries-1,delta.y+size.y-1);
	drawFlag=True;
      };
      break;
    default:
      break;
  };
  drawLock--;
  checkDraw();
};

void TJSList::draw()       // modified for scroller
{
  for( int i = 0; i < size.y; i++ )
  // for each line:
  {
    int j = delta.y + i;       // delta is scroller offset
    ushort color = getColor(1);
    TDrawBuffer b;
    b.moveChar( 0, ' ', color, size.x );
    // fill line buffer with spaces

    if (j<entries) {
      if (j==selected) color = getColor(3);
      else color = getColor(1);
      fillLine(b,j,color);
    };
    writeLine( 0, i, size.x, 1, b);
  }
};

void TJSList::setSelected( long int p) {
  selected = p;
  if (selected < 0) selected = 0;
  if (selected >= entries && entries > 0) selected = entries-1;
  if (entries == 0) selected = 0;
  scrollTo(0,selected);
};

void TJSList::setEntries( long int p) {
  entries = p;
  if (entries < 0) entries = 0;
  if (selected >= entries && entries > 0) selected = entries-1;
  if (entries == 0) selected = 0;
  setLimit(0,entries);
};

/********************************************************************/
/* TInteger                                                         */
/********************************************************************/


TInteger::TInteger( const TRect& bounds ) :
    TView( bounds )
{
  value=0;
}

TInteger::~TInteger()
{
}

TPalette& TInteger::getPalette() const
{
    static TPalette palette( "\x06", 1 );
    return palette;
};

void TInteger::draw() {
  char buf[10];
  ostrstream os(buf,sizeof(buf));
  os << value << ends;
  writeChar(0,0,' ',1,size.x);
  writeStr(0,0,buf,1);

};

