// os2handl.cpp
//
// - Threads and Semaphores
//
// There are a lot of #ifs in this file. It took a long time to get the thread stuff
// working, I kept all the unsuccessful attempts.
//
// Copyright 1993 by J�rn Sierwald

#define Uses_TEventQueue
#define Uses_TScreen
#define Uses_TOS2Handles
#include <tv.h>

#ifdef __TV4ICC__
#  include <errno.h>
#  include <iostream.h>
#endif

#ifdef __TV4EMX__
#  include <sys/errno.h>
#  include <sys/hw.h>
#endif

#ifdef __TV4BCC__
#  include <errno.h>
#  include <process.h>
#  include <string.h>
#  define _Optlink
#  define _strncpy strncpy
#endif

#include <string.h>

#ifdef __TV4OS2__

//HKBD TOS2Handles::keyboardHandle;     // Keyboardhandle is not neccessary.
TiledStruct *
  TOS2Handles::tiled;                   // tiled will be allocated with DosAllocMem. The TiledStruct will
                                        // not cross a 64K boundary, therefore the members can be used by
                                        // 16Bit functions.
volatile TID  
  TOS2Handles::mouseThreadID;           //
volatile TID  
  TOS2Handles::keyboardThreadID;        //
volatile SEMRECORD  
  TOS2Handles::evCombined[2];           // Two Event Semaphores, one for the Mouse and one for Keyboard.
                                        // The main thread will do a MuxWait for both.
volatile HEV &
  TOS2Handles::hevMouse1   = (HEV&) TOS2Handles::evCombined[0].hsemCur;
volatile HEV &
  TOS2Handles::hevKeyboard1= (HEV&) TOS2Handles::evCombined[1].hsemCur;
                                        // Just an alias.
volatile HEV  
  TOS2Handles::hevMouse2;               // _beginthread can't create a suspended thread, so
                                        // we keep it waiting with this one
volatile HEV  
  TOS2Handles::hevKeyboard2;            // Signals that the keypress is received.
volatile HMTX 
  TOS2Handles::hmtxMouse1;              // Access to the internal mouse queue
volatile HMUX 
  TOS2Handles::hmuxMaster;              // MuxWait for evCombined.
volatile int  
  TOS2Handles::shutDownFlag=0;

#ifdef __TV4EMX__
EMXSharedRec* EMXPtr;
#endif

void _Optlink mouseThread( void * arg ) { TEventQueue::mouseThread(arg); };
void _Optlink keyboardThread( void * arg ) { TEventQueue::keyboardThread(arg); };
                                        // ICC doesn't want to call member functions as threads
void TOS2Handles::deadEnd() {
#if 0
  // this function captures a thread as long the shutDownFlag is set.
  // this function is reentrant.
  DosSetPriority(PRTYS_THREAD,PRTYC_IDLETIME,0,0);
  while (shutDownFlag);
  DosSetPriority(PRTYS_THREAD,PRTYC_REGULAR,0,0);
#endif
#if 0
  // Kill The current thread
  cerr << "Thread "
#ifdef __TV4ICC__
       << *_threadid
#endif
       << " is ending.\n";
#endif
  _endthread();
};

TOS2Handles::TOS2Handles() {
};

TOS2Handles::~TOS2Handles() {
};

void TOS2Handles::resume() {
#if 1
//  cerr << "TOS2Handles::resume\n";
#ifdef __TV4EMX__
  if (_osmode == OS2_MODE) {
#endif
  shutDownFlag=0;
  assert(! DosAllocMem((void**)&tiled,sizeof(TiledStruct),fALLOC | OBJ_TILE)    );
  tiled->modeInfo.cb = (unsigned short) sizeof(VIOMODEINFO);
  assert(! MouOpen ((PSZ) 0, &tiled->mouseHandle)                               );

  assert(! DosCreateEventSem( NULL, (PHEV) &hevMouse1, 0, 0 )      );
  assert(! DosCreateEventSem( NULL, (PHEV) &hevMouse2, 0, 0 )      );
  assert(! DosCreateEventSem( NULL, (PHEV) &hevKeyboard1, 0, 0 )   );
  assert(! DosCreateEventSem( NULL, (PHEV) &hevKeyboard2, 0, 0 )   );
  assert(! DosCreateMutexSem( NULL, (PHMTX) &hmtxMouse1, 0, 0 )     );
//  cerr << hevMouse1 << " " << evCombined[0].hsemCur << endl;

  APIRET rc;
  evCombined[0].ulUser=0;
  evCombined[1].ulUser=1;
  rc=(DosCreateMuxWaitSem( NULL, (PHMUX) &hmuxMaster, 2, (PSEMRECORD) evCombined, DCMW_WAIT_ANY ) );
//  cerr << rc << endl;
  assert(!rc);


#ifdef __TV4BCC__
  mouseThreadID = _beginthread(mouseThread,16384,NULL);
#else
  mouseThreadID = _beginthread(mouseThread,NULL,16384,NULL);
#endif
//  DosSuspendThread(mouseThreadID);
  DosPostEventSem(TOS2Handles::hevMouse2);
#ifdef __TV4BCC__
  keyboardThreadID = _beginthread(keyboardThread,16384,NULL);
#else
  keyboardThreadID = _beginthread(keyboardThread,NULL,16384,NULL);
#endif

//  DosSuspendThread(keyboardThreadID);
//  assert(! DosResumeThread( keyboardThreadID ) );
//  KbdOpen( &keyboardHandle ); no keyboard handle is used

#ifdef __TV4EMX__
  };
#endif
#endif
};

void TOS2Handles::suspend() {
//  cerr << "TOS2Handles::suspend1..\n";
//  DosSuspendThread( keyboardThreadID ); // this will probably not work,
                                        // because the keyboardThread calls a 16Bit function.
  APIRET rc;
#ifdef __TV4EMX__
  if (_osmode == OS2_MODE) {
#endif

#if 1
//  DosSleep(3000);
//  cerr << "Set shutdownflag\n";
//  DosSleep(300);
  shutDownFlag=1;
#if 0
  // stuff the Mouse Queue
  // nice try, doesn't work in fullscreen mode.
  assert(! MouDrawPtr (TOS2Handles::tiled->mouseHandle)  );
  DosSleep(1);
  tiled->ptrLoc.row=0;
  tiled->ptrLoc.col=0;
  MouSetPtrPos(&tiled->ptrLoc,tiled->mouseHandle);
  DosSleep(1);
  tiled->ptrLoc.row=1;
  tiled->ptrLoc.col=1;
  MouSetPtrPos(&tiled->ptrLoc,tiled->mouseHandle);
#endif
  TID localTID=mouseThreadID;
//  cerr << "Now wait\n";
//  DosSleep(1000);
  /*cerr <<*/ 
    DosWaitThread(&localTID,DCWW_WAIT);
//  cerr << " MouseThread has ended\n";
  assert(! DosPostEventSem(TOS2Handles::hevKeyboard2) ); // Make sure the thread is running.
  localTID=keyboardThreadID;
  /*cerr << */
    DosWaitThread(&localTID,DCWW_WAIT);
//  cerr << " KeyboardThread has ended\n";
#if 0
  {
    NOPTRRECT *ptrArea = &TOS2Handles::tiled->ptrArea;
    ptrArea->row = ptrArea->col = 0;
    ptrArea->cRow = TScreen::screenHeight-1;
    ptrArea->cCol = TScreen::screenWidth-1;
    APIRET rc = MouRemovePtr (ptrArea, TOS2Handles::tiled->mouseHandle);
    if (rc) {
      cerr << rc << endl;
    };
    assert(!rc);
  };
#endif
#endif

#if 1 
  assert(! DosCloseMutexSem(hmtxMouse1)  );
  assert(! DosCloseEventSem(hevKeyboard2) );
  assert(! DosCloseEventSem(hevKeyboard1) );
  assert(! DosCloseEventSem(hevMouse2) );
  assert(! DosCloseEventSem(hevMouse1) );
  assert(!DosCloseMuxWaitSem(hmuxMaster) );

  MouClose(tiled->mouseHandle);
  assert(! DosFreeMem(tiled) );
#endif

//  KbdClose( keyboardHandle );
#ifdef __TV4EMX__
  };
#endif

//  cerr << "TOS2Handles::suspend2..\n";
};

#endif // TV4OS2

