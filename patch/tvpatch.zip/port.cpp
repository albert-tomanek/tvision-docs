// port.cpp
//
// Functions that are not supplied by icc, wcc or emx but are used by TVision.

#define Uses_TEventQueue
#define Uses_TScreen
#define Uses_TOS2Handles
#include <tv.h>

#ifdef __TV4ICC__
#  include <errno.h>
#  include <iostream.h>
#endif

#ifdef __TV4EMX__
#  include <sys/errno.h>
#  include <sys/hw.h>
#endif

#ifdef __TV4BCC__
#  include <errno.h>
#  include <string.h>
#  define _Optlink
#  define _strncpy strncpy
#endif

#if defined(__TV4WATCOM__)
#  include <errno.h>
#  include <direct.h>
#endif

#if defined(__TV4WATCOMDOS__) || defined(__TV4TS__)
#  include <dos.h>
#endif

#if defined(__TV4DJ__)
#  include <errno.h>
#  include <osfcn.h>
#  include <stdio.h>
#  include <go32.h>
#endif
 
#include <string.h>

#if defined(__TV4ICC__) || defined(__TV4WATCOM__)
char *_strncpy (char *string1, const char *string2, size_t size)
{
  if (size > 0)
    {
      while (size > 1 && *string2 != 0)
        {
          *string1++ = *string2++;
          --size;
        }
      *string1 = 0;
    }
  return (string1);
}
#endif

#if defined(__TV4OS2__) || defined(__TV4WATCOMDOS__)
/* This function Copyright (c) 1992-1993 by Eberhard Mattes */
int _splitpath3 (const char *src, char *drive, char *dir, char *fname,
                 char *ext)
{
  int retVal=0;
  int i, j;

  i = 0;
  while (i < TV_MAXDRIVE-2 && src[i] != 0 && src[i] != ':')
    ++i;
  if (i > 0 && src[i] == ':')
    {
      if (drive != NULL)
        _strncpy (drive, src, i+2);
      src += i+1;
      retVal |= DRIVE;
    }
  else if (drive != NULL)
    *drive = 0;

  i = 0;
  for (j = 0; src[j] != 0; ++j)
    if (src[j] == '/' || src[j] == '\\')
      i = j + 1;
  if (dir != NULL) {
    if (i>0) {
      _strncpy (dir, src, min (TV_MAXPATH, i + 1));
      retVal |= DIRECTORY;
    }
    else
      *dir = 0;
  }
  src += i;

  i = 0;
  for (j = 0; src[j] != 0; ++j)
    if (src[j] == '.')
      i = j;
  if (i == 0)
    i = j;
  if (fname != NULL) {
    _strncpy (fname, src, min (TV_MAXPATH, i + 1));
    retVal |= FILENAME;
  }
  src += i;

  if (ext != NULL) {
    _strncpy (ext, src, TV_MAXEXT);
    if (strlen(ext)>0)
      retVal |= EXTENSION;
  }
  return retVal;
}
#endif

#if (defined(__TV4ICC__) || defined(__TV4EMX__) || defined(__TV4WATCOM__))
int fnsplit(const char *__path,
                            char *__drive,
                            char *__dir,
                            char *__name,
                            char *__ext)
{
  return _splitpath3(__path,__drive,__dir,__name,__ext);
};
#endif

#ifdef __TV4ICC__
/* makepath -- Copyright (c) 1993 by Eberhard Mattes */

void _makepath (char *dst, const char *drive, const char *dir,
                const char *fname, const char *ext)
{
  int n;
  char slash;

  n = 0; slash = '/';
  if (drive != NULL && *drive != 0)
    {
      dst[n++] = *drive;
      dst[n++] = ':';
    }
  if (dir != NULL && *dir != 0)
    {
      while (n < TV_MAXPATH - 1 && *dir != 0)
        {
          if (*dir == '\\')
            slash = '\\';
          dst[n++] = *dir++;
        }
      if (dst[n-1] != '\\' && dst[n-1] != '/' && n < TV_MAXPATH - 1)
        dst[n++] = slash;
    }
  if (fname != NULL)
    {
      while (n < TV_MAXPATH - 1 && *fname != 0)
        dst[n++] = *fname++;
    }
  if (ext != NULL && *ext != 0)
    {
      if (*ext != '.' && n < TV_MAXPATH - 1)
        dst[n++] = '.';
      while (n < TV_MAXPATH - 1 && *ext != 0)
        dst[n++] = *ext++;
    }
  dst[n] = 0;
}
#endif

#if (defined(__TV4ICC__) || defined(__TV4EMX__) || defined(__TV4WATCOM__))
void fnmerge(char *__path,
                            const char *__drive,
                            const char *__dir,
                            const char *__name,
                            const char *__ext)
{
  _makepath(__path,__drive,__dir,__name,__ext);
};

int getdisk(void)
{
#ifdef __TV4EMX__
  return _getdrive() - 'A';
#endif
#if defined(__TV4OS2__) && !defined(__TV4EMX__)
  unsigned long d,map;
  DosQueryCurrentDisk(&d,&map);
  return (int) d-1;
#endif
#if defined(__TV4WATCOMDOS__)
  unsigned int i;
  _dos_getdrive(&i);
  return i-1;
#endif
};
#endif

// getcurdir should fill buffer with the current directory without
// drive char and without a leading backslash.

int getcurdir(int __drive, char *buffer)
{
  long size=TV_MAXPATH; // na hoffentlich.
  char tmp[TV_MAXPATH+1], *p;
  size_t len;
  tmp[0]='\\';
#if defined(__TV4EMX__) || defined(__TV4WATCOMDOS__) || defined (__TV4DJ__)
  if (getcwd (tmp, size) == 0) // getcwd returns a leading backslash
    return (0);
#endif
#if defined(__TV4ICC__) || defined(__TV4BCC__) || defined(__TV4WATCOMOS2__)
  unsigned long l = TV_MAXPATH;
  if (DosQueryCurrentDir(__drive /*0*/ ,tmp+1,&l)) return NULL;
#endif
  len = strlen (tmp) + 2;
  if (buffer == NULL)
    {
      if (size < len) size = len;
      buffer = (char*) malloc (size);
    }
  if (buffer == NULL)
    {
      errno = ENOMEM;
      return (0);
    }
  for (p = tmp; *p != 0; ++p) // no forward slashes please.
    if (*p == '/') *p = '\\';
#if defined(__TV4WATCOMDOS__) || defined(__TV4DJ__)
  // Watcom getcwd returns the drive letter with the path.
  // Is this posix standard? Anyway..
  if (tmp[1]==':') {
    strcpy (buffer, tmp+3);
  } else {
    strcpy (buffer, tmp+1);
  };
#else
  strcpy (buffer, tmp+1);
#endif
  return 0;
};

unsigned long getTicks() {
// return a value that can be used as a substitute for the DOS Ticker at [0040:006C]
#ifdef __TV4EMX__
  static int isReady;
  static volatile unsigned long *ticker;
  if (_osmode == OS2_MODE) {
    unsigned long m;
    DosQuerySysInfo( 14, 14, &m, sizeof(m));
    return m/52;
  } else {
    if (isReady) {
      return *ticker;
    } else {
      ticker=(volatile unsigned long*) (((char*)_memaccess(0,0xFFF,0))+0x46C);
      isReady=1;
      return *ticker;
    };
  };
  return 0; // turn warning off
#endif
#if defined(__TV4OS2__) && !defined(__TV4EMX__) 
    unsigned long m;
    DosQuerySysInfo( 14, 14, &m, sizeof(m));
    return m/52;
#endif
#ifdef __TV4TS__
    return *((unsigned long*) 0x0040006C);
#endif
#ifdef __TV4WATCOMDOS__
    return *((unsigned long*) 0x046C);
#endif
#ifdef __TV4DJ__
    unsigned long temp;
    dosmemget(0x046C,4,&temp);
    return temp;
#endif
};

unsigned char getShiftState() {
// returns a value that can be used as a substitute for the shift state at [0040:0017]
#ifdef __TV4EMX__
  static int isReady;
  static volatile unsigned char *shiftState;
  if (_osmode == OS2_MODE) {
    TOS2Handles::tiled->keyboardShiftInfo.cb = 10;
    KbdGetStatus(&TOS2Handles::tiled->keyboardShiftInfo, 0 );
    return TOS2Handles::tiled->keyboardShiftInfo.fsState & 0xFF;
  } else {
    if (isReady) {
      return *shiftState;
    } else {
      shiftState=(volatile unsigned char*) (((char*)_memaccess(0,0xFFF,0))+0x417);
      isReady=1;
      return *shiftState;
    };
  };
  return 0; // turn warning off
#endif
#if defined(__TV4OS2__) && !defined(__TV4EMX__)
    TOS2Handles::tiled->keyboardShiftInfo.cb = 10;
    KbdGetStatus(&TOS2Handles::tiled->keyboardShiftInfo, 0 );
    return TOS2Handles::tiled->keyboardShiftInfo.fsState & 0xFF;
#endif
#ifdef __TV4TS__
    return *((unsigned char*) 0x00400017);
#endif
#ifdef __TV4WATCOMDOS__
    return *((unsigned char*) 0x0417);
#endif
#ifdef __TV4DJ__
    unsigned char temp;
    dosmemget(0x0417,1,&temp);
    return temp;
#endif

};

#if defined(__TV4DJ__)
long filelength(int file)
{
  long temp1=tell(file);
  long temp2=lseek(file,0,SEEK_END);
  lseek(file,temp1,SEEK_SET);
  return temp2;
}
#endif

