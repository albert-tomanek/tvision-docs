/*
 * TFileList.cc
 *
 * Turbo Vision - Version 2.0
 *
 * Copyright (c) 1994 by Borland International
 * All Rights Reserved.
 *
 * Modified by Sergio Sigala <ssigala@globalnet.it>
 */

#define Uses_TVMemMgr
#define Uses_MsgBox
#define Uses_TFileList
#define Uses_TRect
#define Uses_TSearchRec
#define Uses_TEvent
#define Uses_TGroup
#define Uses_TKeys
#include <tvision/tv.h>

#include <assert.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

void fexpand( char * );

TFileList::TFileList( const TRect& bounds,
                      TScrollBar *aScrollBar) :
    TSortedListBox( bounds, 2, aScrollBar )
{
}

TFileList::~TFileList()
{
   if ( list() )
      destroy ( list() );
}

void TFileList::focusItem( short item )
{
    TSortedListBox::focusItem( item );
    message( owner, evBroadcast, cmFileFocused, list()->at(item) );
}

void TFileList::selectItem( short item )
{
    message( owner, evBroadcast, cmFileDoubleClicked, list()->at(item) );
}

void TFileList::getData( void * )
{
}

void TFileList::setData( void * )
{
}

ushort TFileList::dataSize()
{
    return 0;
}

void* TFileList::getKey( const char *s )
{
static TSearchRec sR;

    if( (shiftState & kbShift) != 0 || *s == '.' )
        sR.attr = FA_DIREC;
    else
        sR.attr = 0;
    strcpy( sR.name, s );

	/* SS: little change */

//    strupr( sR.name );
	for (char *p = sR.name; *p != '\0'; p++) *p = toupper(*p);

    return &sR;
	return NULL;
}

void TFileList::getText( char *dest, short item, short maxChars )
{
    TSearchRec *f = (TSearchRec *)(list()->at(item));

    strncpy( dest, f->name, maxChars );
    dest[maxChars] = '\0';
    if( f->attr & FA_DIREC )
        strcat( dest, "/" );
}


void TFileList::readDirectory( const char *dir, const char *wildCard )
{
    char path[PATH_MAX];
    strcpy( path, dir );
    strcat( path, wildCard );
    readDirectory( path );
}

struct DirSearchRec : public TSearchRec
{
    /* SS: changed */

//    void readFf_blk(ffblk *f)
    void readFf_blk(char *filename)
    {
//        attr = (char)f->ff_attrib;
//    time = (((long)(unsigned)f->ff_fdate)<<16) | f->ff_ftime;
//    size = f->ff_fsize;
//    memcpy(name, f->ff_name, sizeof(name));

	struct stat s;

	if (stat(filename, &s) != 0) return;
	attr = FA_ARCH;
	if (S_ISDIR(s.st_mode)) attr |= FA_DIREC;
	time = 0; /* s.st_mtime s.st_mtime_usec */
	size = s.st_size;
	strcpy(name, filename);
    }

    void *operator new( size_t );

};

void *DirSearchRec::operator new( size_t sz )
{
    void *temp = ::operator new( sz );
    if( TVMemMgr::safetyPoolExhausted() )
        {
        delete temp;
        temp = 0;
        }
    return temp;
}

void TFileList::readDirectory( const char *aWildCard )
{
    /* SS: changed */

/*    ffblk s;
    char path[MAXPATH];
    char drive[MAXDRIVE];
    char dir[MAXDIR];
    char file[MAXFILE];
    char ext[MAXEXT];
    const unsigned findAttr = FA_RDONLY | FA_ARCH;
    memset(&s, 0, sizeof(s));*/

    char path[PATH_MAX];
    strcpy( path, aWildCard );
    fexpand( path );
//    fnsplit( path, drive, dir, file, ext );
	char dir[PATH_MAX];
	char file[PATH_MAX];
	expandPath(path, dir, file);
	strcat(dir, ".");

    TFileCollection *fileList = new TFileCollection( 5, 5 );

	DIR *d = opendir(dir);

//    int res = findfirst( aWildCard, &s, findAttr );
    DirSearchRec *p = (DirSearchRec *)&p;
    dirent *de;

	if (d != NULL)
		while (p != 0 && (de = readdir(d)) != NULL)
//    while( p != 0 && res == 0 )
        {
		struct stat s;

		if (stat(de->d_name, &s) == 0 && S_ISREG(s.st_mode))
//        if( (s.ff_attrib & FA_DIREC) == 0 )
            {
            p = new DirSearchRec;
            if( p != 0 )
                {
	p->readFf_blk(de->d_name);
//        p->readFf_blk(&s);
                fileList->insert( p );
                }
            }
//        res = findnext( &s );
        }
	closedir(d);

//    fnmerge( path, drive, dir, "*", ".*" );
	d = opendir(dir);

//    res = findfirst( path, &s, FA_DIREC );
	if (d != NULL)
		while (d != NULL && (de = readdir(d)) != NULL)
//    while( p != 0 && res == 0 )
        {
		struct stat s;

		if (stat(de->d_name, &s) == 0 && S_ISDIR(s.st_mode) &&
			de->d_name[0] != '.')
//        if( (s.ff_attrib & FA_DIREC) != 0 && s.ff_name[0] != '.' )
            {
            p = new DirSearchRec;
            if( p != 0 )
                {
	p->readFf_blk(de->d_name);
//        p->readFf_blk(&s);
                fileList->insert( p );
                }
            }
//        res = findnext( &s );
        }
	closedir(d);

    if( strlen( dir ) > 1 )
        {
        p = new DirSearchRec;
        if( p != 0 )
            {
//            if( findfirst( path, &s, FA_DIREC ) == 0 &&
//                findnext( &s ) == 0 &&
//                strcmp( s.ff_name, ".." ) == 0
//            )
//            p->readFf_blk(&s);
//            else
//                {
                strcpy( p->name, ".." );
                p->size = 0;
                p->time = 0x210000uL;
                p->attr = FA_DIREC;
//                }
            fileList->insert( p );
            }
        }

    if( p == 0 )
        messageBox( tooManyFiles, mfOKButton | mfWarning );
    newList(fileList);
    if( list()->getCount() > 0 )
        message( owner, evBroadcast, cmFileFocused, list()->at(0) );
    else
        {
        static DirSearchRec noFile;
        message( owner, evBroadcast, cmFileFocused, &noFile );
        }
}

#if !defined(NO_STREAMABLE)

TStreamable *TFileList::build()
{
    return new TFileList( streamableInit );
}

#endif
