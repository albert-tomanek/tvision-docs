/*
 * linux.cc
 *
 * Copyright (C) 1996 Sergio Sigala <ssigala@globalnet.it>
 *
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation.
 *
 * SERGIO SIGALA DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL SERGIO SIGALA BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
 * USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
 * OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

/*
 * This enables the use of colors in remote mode.  The palette should
 * be fixed.
 */
#define REMOTE_COLOR

/*
 * This enables the use of 7 bit characters in remote mode.  8 bit
 * characters (and characters with ascii code < 32) are converted to
 * 7 bit characters with a lookup table.
 */
#define REMOTE_7BIT

/*
 * This is the delay in ms before the first evMouseAuto is generated
 * when the user holds down a mouse button.
 */
#define DELAY_MOUSEAUTO_FIRST	400

/*
 * This is the delay in ms between next evMouseAuto events.
 */
#define DELAY_MOUSEAUTO_NEXT	50

/*
 * This is the delay in ms between consecutive SIGALRM signals.  This
 * signal is used to generate evMouseAuto and cmWakeup events.
 */
#define DELAY_SIGALRM		50

/*
 * This broadcast event is used to update the StatusLine.
 */
#define DELAY_WAKEUP		500

/*
 * This sets the size of the internal event queue.
 */
#define QUEUE_LEN		8

#define Uses_TEvent
#define Uses_TEventQueue
#define Uses_TKeys
#define Uses_TScreen
#include <tvision/tv.h>

#include <ctype.h>
#include <fcntl.h>
#include <iostream.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/kd.h>
#include <sys/time.h>
#include <unistd.h>

extern "C"
{
#include <gpm.h>
};

inline int RANGE(int test, int min, int max)
{
	return test < min ? min : test > max ? max : test;
}

#define TERMINFO_MAGIC		0432	/* terminfo magic number */

struct node_s			/* a node in the key tree */
{
	node_s *child;		/* points to the child */
	node_s *sibling;	/* points to the next character */
	short value;		/* key value */
	char code;		/* character code */
};

struct termheader_s		/* header in terminfo file */
{
	short magic;		/* magic number */
	short name_size;	/* size of the name section */
	short bool_cnt;		/* number of boolean flags */
	short num_cnt;		/* number of numeric flags */
	short str_cnt;		/* number of strings */
	short table_size;	/* size of the string table */
};

/* key modifiers */

#define KALT		kbLeftAlt	/* alt pressed */
#define KCTRL		kbLeftCtrl	/* ctrl pressed */
#define KSHIFT		kbLeftShift	/* shift pressed */
#define KMASK(a)	(a & (KALT | KCTRL | KSHIFT))

/* code types */

#define TALT		0x10		/* alt-letter key */
#define TESC		0x20		/* escape key */
#define TMASK(a)	(a & (TALT | TESC))

typedef struct
{
	ushort out;
	uchar in;
	uchar modifier;
}
keymap_t;

static keymap_t keymap[] =
{
	/* codes < 32 */
	kbCtrlA, 0x01, 0, kbCtrlB, 0x02, 0, kbCtrlC, 0x03, 0,
	kbCtrlD, 0x04, 0, kbCtrlE, 0x05, 0, kbCtrlF, 0x06, 0,
	kbCtrlG, 0x07, 0, kbCtrlH, 0x08, 0, kbCtrlI, 0x09, 0,
	kbCtrlJ, 0x0a, 0, kbCtrlK, 0x0b, 0, kbCtrlL, 0x0c, 0,
	kbCtrlM, 0x0d, 0, kbCtrlN, 0x0e, 0, kbCtrlO, 0x0f, 0,
	kbCtrlP, 0x10, 0, kbCtrlQ, 0x11, 0, kbCtrlR, 0x12, 0,
	kbCtrlS, 0x13, 0, kbCtrlT, 0x14, 0, kbCtrlU, 0x15, 0,
	kbCtrlV, 0x16, 0, kbCtrlW, 0x17, 0, kbCtrlX, 0x18, 0,
	kbCtrlY, 0x19, 0, kbCtrlZ, 0x1a, 0,

	/* ascii codes */
	kbEsc, 27, 0,

	/* alt-letter codes */
	kbAltSpace, ' ', TALT,
	kbAlt0, '0', TALT, kbAlt1, '1', TALT, kbAlt2, '2', TALT,
	kbAlt3, '3', TALT, kbAlt4, '4', TALT, kbAlt5, '5', TALT,
	kbAlt6, '6', TALT, kbAlt7, '7', TALT, kbAlt8, '8', TALT,
	kbAlt9, '9', TALT,
	kbAltA, 'A', TALT, kbAltB, 'B', TALT, kbAltC, 'C', TALT,
	kbAltD, 'D', TALT, kbAltE, 'E', TALT, kbAltF, 'F', TALT,
	kbAltG, 'G', TALT, kbAltH, 'H', TALT, kbAltI, 'I', TALT,
	kbAltJ, 'J', TALT, kbAltK, 'K', TALT, kbAltL, 'L', TALT,
	kbAltM, 'M', TALT, kbAltN, 'N', TALT, kbAltO, 'O', TALT,
	kbAltP, 'P', TALT, kbAltQ, 'Q', TALT, kbAltR, 'R', TALT,
	kbAltS, 'S', TALT, kbAltT, 'T', TALT, kbAltU, 'U', TALT,
	kbAltV, 'V', TALT, kbAltW, 'W', TALT, kbAltX, 'X', TALT,
	kbAltY, 'Y', TALT, kbAltZ, 'Z', TALT,

	/* escape codes: function keys */
	kbF1, 66, TESC, kbF2, 68, TESC,
	kbF3, 69, TESC, kbF4, 70, TESC,
	kbF5, 71, TESC, kbF6, 72, TESC,
	kbF7, 73, TESC, kbF8, 74, TESC,
	kbF9, 75, TESC, kbF10, 67, TESC,
	kbCtrlF1, 66, TESC | KCTRL, kbCtrlF2, 68, TESC | KCTRL,
	kbCtrlF3, 69, TESC | KCTRL, kbCtrlF4, 70, TESC | KCTRL,
	kbCtrlF5, 71, TESC | KCTRL, kbCtrlF6, 72, TESC | KCTRL,
	kbCtrlF7, 73, TESC | KCTRL, kbCtrlF8, 74, TESC | KCTRL,
	kbCtrlF9, 75, TESC | KCTRL, kbCtrlF10, 67, TESC | KCTRL,
	kbShiftF1, 66, TESC | KSHIFT, kbShiftF2, 68, TESC | KSHIFT,
	kbShiftF3, 69, TESC | KSHIFT, kbShiftF4, 70, TESC | KSHIFT,
	kbShiftF5, 71, TESC | KSHIFT, kbShiftF6, 72, TESC | KSHIFT,
	kbShiftF7, 73, TESC | KSHIFT, kbShiftF8, 74, TESC | KSHIFT,
	kbShiftF9, 75, TESC | KSHIFT, kbShiftF10, 67, TESC | KSHIFT,

	/* escape codes: main keyboard */
	kbTab, 134, TESC, kbBack, 55, TESC, kbEnter, 129, TESC,
	kbAltBack, 55, TESC | KALT,
	kbCtrlBack, 55, TESC | KCTRL, kbCtrlEnter, 129, TESC | KCTRL,
	kbShiftTab, 134, TESC | KSHIFT,

	/* escape codes: arrows & friends */
	kbCtrlPrtSc, 0, 0,
	kbIns, 77, TESC, kbHome, 76, TESC,
	kbPgUp, 82, TESC, kbDel, 59, TESC,
	kbEnd, 164, TESC, kbPgDn, 81, TESC,
	kbUp, 87, TESC, kbLeft, 79, TESC,
	kbDown, 61, TESC, kbRight, 83, TESC,
	kbCtrlIns, 77, TESC | KCTRL, kbCtrlHome, 76, TESC | KCTRL,
	kbCtrlPgUp, 82, TESC | KCTRL, kbCtrlDel, 59, TESC | KCTRL,
	kbCtrlEnd, 164, TESC | KCTRL, kbCtrlPgDn, 81, TESC | KCTRL,
	kbCtrlLeft, 79, TESC | KCTRL, kbCtrlRight, 83, TESC | KCTRL,

	/* unsupported codes */
	kbAltF1, 0, 0, kbAltF2, 0, 0, kbAltF3, 0, 0, kbAltF4, 0, 0,
	kbAltF5, 0, 0, kbAltF6, 0, 0, kbAltF7, 0, 0, kbAltF8, 0, 0,
	kbAltF9, 0, 0, kbAltF10, 0, 0,
	kbAltMinus, 0, 0, kbAltEqual, 0, 0,
	kbGrayMinus, 0, 0, kbGrayPlus, 0, 0
};

/* lookup table to translate characters from pc set to standard ascii */

static unsigned char pctoascii[] =
{
	" OOooooooooo!!!*><|!!O_|^V><--^V !\"#$%&'()*+,-./0123456789:;<=>?"
	"@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~d"
	"cueaaaaceeeiiiaaeafooouuyOUcLYPfaiounN--?--//!<>:%%|{+++++I+'++."
	"`++}-+++`.+++=+++++++++++'.|-||-abipeouyooooooEn=+><()-=o..Vn2X "
};

ushort TEventQueue::doubleDelay = 8;
Boolean TEventQueue::mouseReverse = False;

ushort TScreen::screenMode;
uchar TScreen::screenWidth;
uchar TScreen::screenHeight;
ushort *TScreen::screenBuffer;

static TEvent *in;		/* message queue system */
static TEvent *out;
static TEvent queue[QUEUE_LEN];
static TPoint where;
static fd_set set;		/* used for select() */
static int flag_mouseauto;	/* counters set in signal handler */
static int flag_repaint;
static int flag_wakeup;
static int length;		/* number of events in the queue */
static int ms_fd;		/* mouse file descriptor */
static int ms_oldbuttons;	/* mouse button status */
static int timer_mouseauto;	/* timers used to generate events */
static int timer_wakeup;
static int out_fd;		/* output descriptor */
static node_s *kb_root;		/* key string structure */
static termios oldtermios;	/* old console properties */
static termios newtermios;	/* current console properties */

/*
 * Inserts a key string in the tree.
 */

void TScreen::kbAddKey(char *str, short value)
{
	node_s *tag;

	/* don't allow strings like \Ec or \E7 */

	if (str[0] == '\x1b' && isalnum(str[1])) return;

	/* the root not exists ? */

	if (kb_root == NULL) kb_root = kbCreateNode(*str);
	tag = kb_root;

	while (*str != '\0')
	{
		node_s *prev = NULL;

		/* checks if the entry exists */

		while (tag != NULL && tag->code != *str)
		{
			prev = tag;
			tag = tag->sibling;
		}

		/* entry not exists, so creates one */

		if (tag == NULL)
		{
			prev->sibling = tag = kbCreateNode(*str);
		}

		/* one character is scanned */

		if (*++str != '\0')
		{
			/* if entry has childs goes to the first of them */

			if (tag->child != NULL) tag = tag->child;
			else do
			{
				/* otherwise creates the childs */

				tag->child = kbCreateNode(*str);
				tag = tag->child;
			}
			while (*++str != '\0');
		}
	}
	tag->value = value;
}

/*
 * Builds the tree by inserting all the key strings.
 */

void TScreen::kbBuildTree(short *offset, char *table, int count)
{
	int i;

	cerr << __FILE__": terminfo table has " << count << " entries\n";
	kb_root = NULL;
	for (i = 0; i < count; i++)
	{
		if (offset[i] >= 0) kbAddKey(table + offset[i], i);
	}
}

/*
 * Creates a node and returns its address.
 */

node_s *TScreen::kbCreateNode(char code)
{
	node_s *node = new node_s;

	node->child = node->sibling = NULL;
	node->code = code;
	node->value = -1;
	return node;
}

/*
 * Gets characters from the console, checks if they are escape sequences
 * or meta characters and puts the appropriate event in the queue.
 */

void TScreen::kbHandle(unsigned char *buf, int len)
{
	TEvent event;
	int modifier, pos = 0;

	event.keyDown.controlKeyState = modifier = kbReadShiftState();
	event.what = evKeyDown;

	/* loop until the end of the buffer */

	while (pos < len)
	{
		int code, type, chk = pos;
		int ok = 0;
		node_s *prev = NULL;
		node_s *tag = kb_root;

		/* if it can be an escape sequence starts the search */

		while (chk < len && tag != NULL)
		{
			/* finds the character in the sibling list */

			while (tag != NULL && tag->code != buf[chk])
			{
				tag = tag->sibling;
			}

			/* if the entry exists checks in its childs */

			if (tag != NULL)
			{
				/* if it can be a valid key remember it */

				chk++;
				if (tag->value >= 0)
				{
					prev = tag;
					ok = chk;
				}
				tag = tag->child;
			}
		}

		/* is it an escape key ? */

		if (prev != NULL && prev->value >= 0)
		{
			code = prev->value;
			type = TESC;
			pos = ok;
		}
		else if (buf[pos] == 0x1b && len - pos >= 2)
		{
			/* is it a meta key ? */

			code = toupper(buf[++pos]);
			type = TALT;
			pos++;
		}
		else
		{
			/* standard ASCII key */

			code = buf[pos++];
			type = 0;
		}
		event.keyDown.keyCode = kbMapKey(code, type | modifier);
		putEvent(event);
	}
}

/*
 * Builds a keycode from code and modifiers.  This is a hack.
 */

int TScreen::kbMapKey(int code, int mod)
{
	keymap_t *best, *p;

	for (best = NULL, p = keymap; p < keymap + sizeof(keymap); p++)
	{
		/* code and type must match */

		if (p->in == code && TMASK(p->modifier) == TMASK(mod))
		{
			/*
			 * now get the best keycode we have, modifier keys
			 * may differ
			 */
			if (best == NULL || KMASK(p->modifier) == KMASK(mod))
			{
				best = p;
			}
		}
	}
	if (best != NULL) return best->out;	/* keycode found */
	if (TMASK(mod) == 0) return code;	/* it is an ascii character */
	return kbNoKey;
}

/*
 * Gets information about modifier keys (Alt, Ctrl and Shift).  This can
 * be done only if the program runs on the system console.
 */

int TScreen::kbReadShiftState()
{
	int arg = 6;	/* TIOCLINUX function #6 */
	int shift = 0;

	if (ioctl(STDIN_FILENO, TIOCLINUX, &arg) != -1)
	{
		if (arg & (2 | 8)) shift |= kbLeftAlt | kbRightAlt;
		if (arg & 4) shift |= kbLeftCtrl | kbRightCtrl;
		if (arg & 1) shift |= kbLeftShift | kbRightShift;
	}
	return shift;
}

/*
 * Recursive function to destroy a node and its childs.
 */

void TScreen::kbKillTree(node_s *base)
{
	if (base != NULL)
	{
		node_s *next = base->sibling;

		kbKillTree(base->child);
		delete base;
		base = next;
	}
}

/*
 * Reads the terminfo compiled file.
 */

int TScreen::kbLoadTerm()
{
	FILE *fs;
	char *dir, *term, path[PATH_MAX];
	termheader_s h;

	if ((dir = getenv("TERMINFO")) == NULL)
	{
		dir = "/usr/lib/terminfo";
	}
	if ((term = getenv("TERM")) == NULL)
	{
		cerr << __FILE__": environment variable TERM not set\n";
		return -1;
	}
	sprintf(path, "%s/%c/%s", dir, term[0], term);

	/* open the file */

	if ((fs = fopen(path, "r")) == NULL)
	{
		cerr << __FILE__": unable to open terminfo " << path << "\n";
		return -1;
	}
	cerr << __FILE__": read terminfo " << path << "\n";

	/* read the header */

	if (fread(&h, sizeof(h), 1, fs) != 1)
	{
		fclose(fs);
		cerr << __FILE__": unable to read terminfo " << path << "\n";
		return -1;
	}

	/* check file type */

	if (h.magic == TERMINFO_MAGIC)
	{
		int skip_bytes = h.name_size + h.bool_cnt;

		/* align to an even word boundary */

		if ((skip_bytes % 2) != 0) skip_bytes++;
		skip_bytes += sizeof(short) * h.num_cnt;

		/* move to offset table */

		if (fseek(fs, skip_bytes, SEEK_CUR) == 0)
		{
			short *off = new short [h.str_cnt];

			/* read offset table */

			if (fread(off, sizeof(short) * h.str_cnt, 1, fs) == 1)
			{
				char *table = new char [h.table_size];

				/* read string table */

				if (fread(table, h.table_size, 1, fs) == 1)
				{
					fclose(fs);
					kbBuildTree(off, table, h.str_cnt);
					delete off, table;
					return 0;
				}
				delete table;
			}
			delete off;
		}
	}
	fclose(fs);
	cerr << __FILE__": bad terminfo " << path << "\n";
	return -1;
}

/*
 * Mouse handler called by Gpm_Getchar().
 */

void TScreen::msHandle(Gpm_Event *mev)
{
	TEvent event;

	event.mouse.controlKeyState = kbReadShiftState();
	event.mouse.where.x = RANGE(mev->x, 0, screenWidth - 1);
	event.mouse.where.y = RANGE(mev->y, 0, screenHeight - 1);
	if (mev->type & GPM_DOUBLE && mev->type & GPM_UP)
	{
		event.mouse.buttons = ms_oldbuttons;
		event.mouse.eventFlags = meDoubleClick;
		event.what = evMouseDown;
		msPut(event);
	}
	if (mev->type & (GPM_DRAG | GPM_MOVE))
	{
		event.mouse.buttons = mev->buttons;
		event.mouse.eventFlags = meMouseMoved;
		event.what = evMouseMove;
		msPut(event);

		/* save mouse status */

		ms_oldbuttons = mev->buttons;
		timer_mouseauto = -1;

		/* redraw the mouse in the new place */

		scDrawMouse(0);
		where.x = event.mouse.where.x;
		where.y = event.mouse.where.y;
		scDrawMouse(1);
	}
	if (mev->type & GPM_DOWN)
	{
		event.mouse.buttons = mev->buttons & ~ms_oldbuttons;
		event.mouse.eventFlags = 0;
		event.what = evMouseDown;
		msPut(event);

		/* save mouse status */

		ms_oldbuttons = mev->buttons;
		timer_mouseauto = DELAY_MOUSEAUTO_FIRST;
	}
	if (mev->type & GPM_UP)
	{
		event.mouse.buttons = mev->buttons;
		event.mouse.eventFlags = 0;
		event.what = evMouseUp;
		msPut(event);

		/* save mouse status */

		ms_oldbuttons &= ~mev->buttons;
		timer_mouseauto = -1;
	}
}

/*
 * Store mouse event.
 */

void TScreen::msPut(TEvent &event)
{
	if (event.mouse.buttons != 0)
	{
		int b = 0;

		if (event.mouse.buttons & GPM_B_LEFT) b |= mbLeftButton;
		if (event.mouse.buttons & GPM_B_RIGHT) b |= mbRightButton;
		if (TEventQueue::mouseReverse == True && b != 0 && b != 3)
		{
			b ^= 3;
		}
		event.mouse.buttons = b;
	}
	putEvent(event);
}

/*
 * Hides or shows the mouse pointer.
 */

void TScreen::scDrawMouse(int show)
{
	if (ms_fd >= 0)
	{
		int addr = screenWidth * where.y + where.x;
		ushort cell = screenBuffer[addr];

		if (out_fd == STDOUT_FILENO)
		{
			char out[1024];
			int ch = cell & 0xff, len;

#ifdef REMOTE_7BIT
			ch = pctoascii[ch];
#endif
			if (show) len = sprintf(out,
				"\0337"		/* save cursor position */
				"\033[%d;%dH"	/* move cursor */
				"\033[7m"	/* enter reverse mode */
				"%c"		/* draw character */
				"\033[m"	/* exit reverse mode */
				"\0338",	/* restore cursor position */
				where.y + 1, where.x + 1, ch);
			else len = sprintf(out,
				"\0337"		/* save cursor position */
				"\033[%d;%dH"	/* move cursor */
				"%c"		/* draw character */
				"\0338",	/* restore cursor position */
				where.y + 1, where.x + 1, ch);
			write(out_fd, out, len);
		}
		else	/* console mode */
		{
			if (show) cell ^= 0x7f00;
			lseek(out_fd, addr * sizeof(ushort) + 4, SEEK_SET);
			write(out_fd, &cell, sizeof(ushort));
		}
	}
}

/*
 * Moves the cursor to another place.
 */

void TScreen::scMoveCursor(int x, int y)
{
	if (out_fd == STDOUT_FILENO)
	{ 
		char out[1024];

		write(out_fd, out, sprintf(out, "\033[%d;%dH", y + 1, x + 1));
	}
	else	/* console mode */
	{
		unsigned char where[2];

		where[0] = x;
		where[1] = y;
		lseek(out_fd, 2, SEEK_SET);
		write(out_fd, where, sizeof(where));
	}
}

/*
 * Draws a line of text on the screen.
 */

void TScreen::scWriteRow(int dst, ushort *src, int len)
{
	if (out_fd == STDOUT_FILENO)
	{
		ushort *old = screenBuffer + dst;
		ushort *old_right = old + len - 1;
		ushort *src_right = src + len - 1;

		/* remove unchanged characters from left to right */

		while (len > 0 && *old == *src)
		{
			dst++;
			len--;
			old++;
			src++;
		}

		/* remove unchanged characters from right to left */

		while (len > 0 && *old_right == *src_right)
		{
			len--;
			old_right--;
			src_right--;
		}

		/* write only middle changed characters */

		if (len > 0)
		{
			char out[1024];
			int col = -1, i;

			i = sprintf(out,
				"\0337"		/* save cursor position */
				"\033[%d;%dH",	/* move cursor */
				dst / screenWidth + 1,
				dst % screenWidth + 1);
			while (len-- > 0)
			{
				*old++ = *src;

				/* change color ? */
#ifdef REMOTE_COLOR
				if (col == -1 || col != *src >> 8)
				{
					/* set foreground color */

					col = *src >> 8;
					i += sprintf(out + i, "\033[3%dm",
					col & 0x7);
				}
#endif
				int ch = *src++ & 0xff;
#ifdef REMOTE_7BIT
				ch = pctoascii[ch];
#endif
				out[i++] = ch;
			}
			out[i++] = '\033';
			out[i++] = '8';		/* restore cursor position */
			write(out_fd, out, i);
		}
	}
	else	/* console mode */
	{
		lseek(out_fd, dst * sizeof(ushort) + 4, SEEK_SET);
		write(out_fd, src, len * sizeof(ushort));
	}
}

/*
 * Gets an event from the queue.
 */

void TScreen::getEvent(TEvent &event)
{
	event.what = evNothing;
	if (length > 0)		/* handles pending events */
	{
		length--;
		event = *out;
		if (++out == &queue[QUEUE_LEN]) out = &queue[0];
	}
	else if (flag_mouseauto > 0)
	{
		flag_mouseauto--;
		event.mouse.buttons = ms_oldbuttons;
		event.what = evMouseAuto;
	}
	else if (flag_repaint > 0)
	{
		flag_repaint--;
		event.message.command = cmRepaint;
		event.what = evCommand;

		/* discard buffer */

		if (out_fd == STDOUT_FILENO) memset(screenBuffer, 0,
			screenWidth * screenHeight * sizeof(ushort));
	}
	else if (flag_wakeup > 0)
	{
		flag_wakeup--;
		event.message.command = cmWakeup;
		event.what = evBroadcast;
	}
	else
	{
		fd_set ready = set;

		/*
		 * suspend until there is a signal or some data in file
		 * descriptors
		 */
		if (select(FD_SETSIZE, &ready, NULL, NULL, NULL) > 0)
		{
			if (FD_ISSET(STDIN_FILENO, &ready))
			{
				unsigned char buf[256];

				kbHandle(buf, read(STDIN_FILENO, buf,
					sizeof(buf)));
			}
			if (ms_fd >= 0 && FD_ISSET(ms_fd, &ready))
			{
				Gpm_Event mev;

				Gpm_GetEvent(&mev);
				msHandle(&mev);
			}
		}
	}
}

/*
 * Generates a beep.
 */

void TScreen::makeBeep()
{
	/*
	 * high word = clock ticks
	 * low word = counter value (1193180 / frequency)
	 */
	ioctl(STDIN_FILENO, KDMKTONE, 0x005004a9);
}

/*
 * Puts an event in the queue.  If the queue is full the event will be
 * discarded.
 */

void TScreen::putEvent(TEvent &event)
{
	if (length < QUEUE_LEN)
	{
		length++;
		*in = event;
		if (++in == &queue[QUEUE_LEN]) in = &queue[0];
	}
}

/*
 * General signal handler.
 */

void TScreen::sigHandler(int signo)
{
	switch (signo)
	{
	case SIGALRM:
		/*
		 * called every DELAY_SIGALRM ms
		 */
		signal(SIGALRM, sigHandler);
		if (timer_mouseauto >= 0)
		{
			if ((timer_mouseauto -= DELAY_SIGALRM) <= 0)
			{
				flag_mouseauto++;
				timer_mouseauto = DELAY_MOUSEAUTO_NEXT;
			}
		}
		if ((timer_wakeup -= DELAY_SIGALRM) <= 0)
		{
			flag_wakeup++;
			timer_wakeup = DELAY_WAKEUP;
		}
		break;
	case SIGCONT:
		/*
		 * called when the user restart the process after a ctrl-z
		 */
		signal(SIGCONT, sigHandler);
		signal(SIGTSTP, sigHandler);
		flag_repaint++;
		tcsetattr(STDIN_FILENO, TCSAFLUSH, &newtermios);
		cerr << __FILE__": continuing process\n";
		break;
	case SIGTSTP:
		/*
		 * called when the user presses ctrl-z
		 */
		write(STDOUT_FILENO, "\033[H\033[J", 6); /* clear screen */
		cerr << __FILE__": process stopped, type 'fg' to resume\n";
		tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldtermios);
		signal(SIGTSTP, SIG_DFL);	/* use default handler */
		raise(SIGTSTP);		/* stop the process */
	}
}

/*
 * TScreen constructor.
 */

TScreen::TScreen()
{
	Gpm_Connect conn;
	char *term;
	int console_no = -1;
	struct itimerval timer;

	/* load terminfo */

	if (kbLoadTerm() < 0) exit(EXIT_FAILURE);

	/* other stuff */

	flag_mouseauto = flag_repaint = flag_wakeup = 0;
	in = out = &queue[0];
	length = 0;
	timer_mouseauto = -1;
	timer_wakeup = DELAY_WAKEUP;

	/* mouse stuff */

	conn.eventMask = ~0;		/* I want all events */
	conn.defaultMask = 0;		/* no default treatment */
	conn.maxMod = ~0;
	conn.minMod = 0;
	gpm_zerobased = 1;		/* coordinates start from zero */
	if ((ms_fd = Gpm_Open(&conn, 0)) < 0)
	{
		winsize win;

		cerr << __FILE__": no Gpm, running without mouse\n";
		ioctl(STDIN_FILENO, TIOCGWINSZ, &win);
		if (win.ws_col > 0 && win.ws_row > 0)
		{
			screenWidth = win.ws_col;
			screenHeight = win.ws_row;
		}
		else
		{
			cerr << __FILE__": unable to detect screen size\n";
			screenWidth = 80;
			screenHeight = 25;
		}
	}
	else
	{
		cerr << __FILE__": Gpm server version is " <<
			Gpm_GetServerVersion(NULL) << "\n";
		screenWidth = gpm_mx + 1;
		screenHeight = gpm_my + 1;
	}
	cerr << __FILE__": screen is " << (int) screenWidth << "x" <<
		(int) screenHeight << "\n";
	where.x = where.y = ms_oldbuttons = 0;

	/* input stuff */

	tcgetattr(STDIN_FILENO, &oldtermios);
	newtermios = oldtermios;

	/*
	 * ECHO		enables echoing of the input characters back to the
	 *		terminal
	 * ICANON	enables canonical mode with editing facilities
	 */
	newtermios.c_lflag &= ~(ECHO | ICANON);

	/*
	 * VMIN		specifies the minimum number of bytes that must be
	 *		available in the input queue in order for read() to
	 *		return
	 * VTIME	specifies how long to wait for input before
	 *		returning, in units of 0.1 seconds
	 */
	newtermios.c_cc[VMIN] = 1;
	newtermios.c_cc[VTIME] = 0;
	tcsetattr(STDIN_FILENO, TCSAFLUSH, &newtermios);

	/* output stuff */

	if ((term = ttyname(STDOUT_FILENO)) != NULL)
	{
		cerr << __FILE__": you are connected in " << term << "\n";
		if (memcmp(term, "/dev/tty", 8) == 0)
		{
			char *tail, *test = term + 8;

			/*
			 * terminals like tty1 are system console, others like
			 * ttyS1 or ttyp1 are remote connections, so if
			 * conversion fails we are running remotely
			 */
			console_no = strtol(test, &tail, 10);
			if (test == tail) console_no = -1;
		}
	}
	if (console_no >= 0)
	{
		char dev[PATH_MAX];

		cerr << __FILE__": running in console mode\n";
		sprintf(dev, "/dev/vcsa%d", console_no);
		if ((out_fd = open(dev, O_WRONLY)) < 0)
		{
			cerr << __FILE__": unable to open " << dev << "\n";
			exit(EXIT_FAILURE);
		}
	}
	else
	{
		cerr << __FILE__": running in remote mode\n";
		out_fd = STDOUT_FILENO;
	}
	screenBuffer = new ushort[screenWidth * screenHeight];
	screenMode = smCO80;

	/* setup file descriptors */

	FD_ZERO(&set);
	FD_SET(STDIN_FILENO, &set);
	if (ms_fd >= 0) FD_SET(ms_fd, &set);

	/* catch useful signals */

	signal(SIGALRM, sigHandler);
	signal(SIGCONT, sigHandler);
	signal(SIGTSTP, sigHandler);

	/* generates a SIGALRM signal every DELAY_SIGALRM ms */

	timer.it_interval.tv_usec = timer.it_value.tv_usec =
		DELAY_SIGALRM * 1000;
	timer.it_interval.tv_sec = timer.it_value.tv_sec = 0;
	setitimer(ITIMER_REAL, &timer, NULL);
}

/*
 * TScreen destructor.
 */

TScreen::~TScreen()
{
	suspend();
	write(STDOUT_FILENO, "\033[H\033[J", 6);	/* clear screen */
	kbKillTree(kb_root);
	tcsetattr(STDIN_FILENO, TCSAFLUSH, &oldtermios);
	if (ms_fd >= 0) Gpm_Close();
	if (out_fd != STDOUT_FILENO) close(out_fd);
	delete screenBuffer;
	cerr << __FILE__": terminated\n";
}

void TScreen::resume()
{
    /* SS: stuff removed */

/*    startupMode = getCrtMode();
    startupCursor = getCursorType();
    if (screenMode != startupMode)
        setCrtMode( screenMode );
    setCrtData();*/
}

void TScreen::suspend()
{
    /* SS: stuff removed */

/*#ifdef __PATCHED
    if( startupMode != getCrtMode() )
#else
    if( startupMode != screenMode )
#endif
        setCrtMode( startupMode );
    if (clearOnSuspend)
      clearScreen();
    setCursorType( startupCursor );*/
}

/*
 * Returns the length of a file.
 */

long int filelength(int fd)
{
	long int save = lseek(fd, 0, SEEK_CUR);
	long int len = lseek(fd, 0, SEEK_END);

	lseek(fd, save, SEEK_SET);
	return len;
}

/*
 * Standard strncpy() is braindead.
 */

void strncpy2(char *to, const char *from, int size)
{
	while (size-- > 0 && *from != '\0')
	{
		*to++ = *from++;
	}
	*to = '\0';
}

/*
 * Expands a path into its directory and file components.
 */

void expandPath(const char *path, char *dir, char *file)
{
	char *tag = strrchr(path, '/');

	/* the path is in the form /dir1/dir2/file ? */

	if (tag != NULL)
	{
		strcpy(file, tag + 1);
		strncpy2(dir, path, tag - path + 1);
	}
	else
	{
		/* there is only the file name */

		strcpy(file, path);
		dir[0] = '\0';
	}
}

void fexpand(char *path)
{
	char dir[PATH_MAX];
	char file[PATH_MAX];
	char oldPath[PATH_MAX];

	expandPath(path, dir, file);
	getcwd(oldPath, sizeof(oldPath));
	chdir(dir);
	getcwd(dir, sizeof(dir));
	chdir(oldPath);
	if (strcmp(dir, "/") == 0) sprintf(path, "/%s", file);
	else sprintf(path, "%s/%s", dir, file);
}
