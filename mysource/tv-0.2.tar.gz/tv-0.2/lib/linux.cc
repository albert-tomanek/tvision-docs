/*
 * linux.cc
 *
 * Copyright (C) 1996 Sergio Sigala <ssigala@globalnet.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define Uses_TEvent
#define Uses_TEventQueue
#define Uses_TKeys
#define Uses_TScreen
#include <tvision/tv.h>

#include <ctype.h>
#include <fcntl.h>
#include <iostream.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/kd.h>
#include <sys/time.h>
#include <unistd.h>

extern "C"
{
#include <gpm.h>
};

#include <curses.h>
#include <term.h>
#undef buttons		/* delete this line and see what happens :-) */

/*
 * This is the time limit in ms within Esc-key sequences are detected as
 * Alt-letter sequences.  Useful when we can't generate Alt-letter sequences
 * directly.
 */
#define DELAY_ESCAPE		400

/*
 * This is the delay in ms before the first evMouseAuto is generated
 * when the user holds down a mouse button.
 */
#define DELAY_MOUSEAUTO_FIRST	400

/*
 * This is the delay in ms between next evMouseAuto events.  Must be
 * greater than DELAY_SIGALRM.
 */
#define DELAY_MOUSEAUTO_NEXT	75

/*
 * This is the delay in ms between consecutive SIGALRM signals.  This
 * signal is used to generate evMouseAuto and cmLinuxWakeup events.
 */
#define DELAY_SIGALRM		50

/*
 * This broadcast event is used to update the StatusLine.
 */
#define DELAY_WAKEUP		200

/*
 * This sets the size of the internal event queue.
 */
#define QUEUE_LEN		8

extern char *program_invocation_short_name;

#define LOG(s) cerr << program_invocation_short_name << ": " << s << "\n";

/* key modifiers */

#define MALT		(kbLeftAlt | kbRightAlt)
#define MCTRL		(kbLeftCtrl | kbRightCtrl)
#define MSHIFT		(kbLeftShift | kbRightShift)

/* key types */

#define TALT		0x01		/* alt-letter key */

typedef struct
{
	int in;
	char type;
	char modifiers;
	short out;
}
keymap_t;

static keymap_t keymap[] =
{
	/* ascii codes */

	1, 0, 0, kbCtrlA, 2, 0, 0, kbCtrlB, 3, 0, 0, kbCtrlC,
	4, 0, 0, kbCtrlD, 5, 0, 0, kbCtrlE, 6, 0, 0, kbCtrlF,
	7, 0, 0, kbCtrlG, 8, 0, 0, kbCtrlH, 9, 0, 0, kbCtrlI,
	10, 0, 0, kbCtrlJ, 11, 0, 0, kbCtrlK, 12, 0, 0, kbCtrlL,
	13, 0, 0, kbCtrlM, 14, 0, 0, kbCtrlN, 15, 0, 0, kbCtrlO,
	16, 0, 0, kbCtrlP, 17, 0, 0, kbCtrlQ, 18, 0, 0, kbCtrlR,
	19, 0, 0, kbCtrlS, 20, 0, 0, kbCtrlT, 21, 0, 0, kbCtrlU,
	22, 0, 0, kbCtrlV, 23, 0, 0, kbCtrlW, 24, 0, 0, kbCtrlX,
	25, 0, 0, kbCtrlY, 26, 0, 0, kbCtrlZ, 9, 0, 0, kbTab,
	10, 0, 0, kbEnter, 27, 0, 0, kbEsc, 31, 0, 0, kbCtrlBack,
	127, 0, 0, kbBack,

	9, 0, MSHIFT, kbShiftTab,

	/* alt-letter codes */

	' ', TALT, 0, kbAltSpace,
	'0', TALT, 0, kbAlt0, '1', TALT, 0, kbAlt1, '2', TALT, 0, kbAlt2,
	'3', TALT, 0, kbAlt3, '4', TALT, 0, kbAlt4, '5', TALT, 0, kbAlt5,
	'6', TALT, 0, kbAlt6, '7', TALT, 0, kbAlt7, '8', TALT, 0, kbAlt8,
	'9', TALT, 0, kbAlt9,
	'A', TALT, 0, kbAltA, 'B', TALT, 0, kbAltB, 'C', TALT, 0, kbAltC,
	'D', TALT, 0, kbAltD, 'E', TALT, 0, kbAltE, 'F', TALT, 0, kbAltF,
	'G', TALT, 0, kbAltG, 'H', TALT, 0, kbAltH, 'I', TALT, 0, kbAltI,
	'J', TALT, 0, kbAltJ, 'K', TALT, 0, kbAltK, 'L', TALT, 0, kbAltL,
	'M', TALT, 0, kbAltM, 'N', TALT, 0, kbAltN, 'O', TALT, 0, kbAltO,
	'P', TALT, 0, kbAltP, 'Q', TALT, 0, kbAltQ, 'R', TALT, 0, kbAltR,
	'S', TALT, 0, kbAltS, 'T', TALT, 0, kbAltT, 'U', TALT, 0, kbAltU,
	'V', TALT, 0, kbAltV, 'W', TALT, 0, kbAltW, 'X', TALT, 0, kbAltX,
	'Y', TALT, 0, kbAltY, 'Z', TALT, 0, kbAltZ, 127, TALT, 0, kbAltBack,

	/* escape codes */

	KEY_DOWN, 0, 0, kbDown, KEY_UP, 0, 0, kbUp, KEY_LEFT, 0, 0, kbLeft,
	KEY_RIGHT, 0, 0, kbRight, KEY_HOME, 0, 0, kbHome,
	KEY_BACKSPACE, 0, 0, kbBack, KEY_F(1), 0, 0, kbF1,
	KEY_F(2), 0, 0, kbF2, KEY_F(3), 0, 0, kbF3, KEY_F(4), 0, 0, kbF4,
	KEY_F(5), 0, 0, kbF5, KEY_F(6), 0, 0, kbF6, KEY_F(7), 0, 0, kbF7,
	KEY_F(8), 0, 0, kbF8, KEY_F(9), 0, 0, kbF9, KEY_F(10), 0, 0, kbF10,
	KEY_DC, 0, 0, kbDel, KEY_IC, 0, 0, kbIns, KEY_NPAGE, 0, 0, kbPgDn,
	KEY_PPAGE, 0, 0, kbPgUp, KEY_END, 0, 0, kbEnd,

	KEY_LEFT, 0, MCTRL, kbCtrlLeft, KEY_RIGHT, 0, MCTRL, kbCtrlRight,
	KEY_HOME, 0, MCTRL, kbCtrlHome, KEY_F(1), 0, MCTRL, kbCtrlF1,
	KEY_F(2), 0, MCTRL, kbCtrlF2, KEY_F(3), 0, MCTRL, kbCtrlF3,
	KEY_F(4), 0, MCTRL, kbCtrlF4, KEY_F(5), 0, MCTRL, kbCtrlF5,
	KEY_F(6), 0, MCTRL, kbCtrlF6, KEY_F(7), 0, MCTRL, kbCtrlF7,
	KEY_F(8), 0, MCTRL, kbCtrlF8, KEY_F(9), 0, MCTRL, kbCtrlF9,
	KEY_F(10), 0, MCTRL, kbCtrlF10, KEY_DC, 0, MCTRL, kbCtrlDel, 
	KEY_IC, 0, MCTRL, kbCtrlIns, KEY_NPAGE, 0, MCTRL, kbCtrlPgDn,
	KEY_PPAGE, 0, MCTRL, kbCtrlPgUp, KEY_END, 0, MCTRL, kbCtrlEnd,

	KEY_F(11), 0, MSHIFT, kbShiftF1, KEY_F(12), 0, MSHIFT, kbShiftF2,
	KEY_F(13), 0, MSHIFT, kbShiftF3, KEY_F(14), 0, MSHIFT, kbShiftF4,
	KEY_F(15), 0, MSHIFT, kbShiftF5, KEY_F(16), 0, MSHIFT, kbShiftF6,
	KEY_F(17), 0, MSHIFT, kbShiftF7, KEY_F(18), 0, MSHIFT, kbShiftF8,
	KEY_F(19), 0, MSHIFT, kbShiftF9, KEY_F(20), 0, MSHIFT, kbShiftF10,
	KEY_DC, 0, MSHIFT, kbShiftDel, KEY_IC, 0, MSHIFT, kbShiftIns
};

/* lookup table to translate characters from pc set to standard ascii */

static unsigned char pctoascii[] =
{
	" OOooooooooo!!!*><|!!O_|^V><--^V !\"#$%&'()*+,-./0123456789:;<=>?"
	"@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~d"
	"cueaaaaceeeiiiaaeafooouuyOUcLYPfaiounN--?--//!<>:%%|{+++++I+'++."
	"`++}-+++`.+++=+++++++++++'.|-||-abipeouyooooooEn=+><()-=o..Vn2X "
};

ushort TEventQueue::doubleDelay = 8;
Boolean TEventQueue::mouseReverse = False;

ushort TScreen::screenMode;
uchar TScreen::screenWidth;
uchar TScreen::screenHeight;
ushort *TScreen::screenBuffer;

static TEvent *in;		/* message queue system */
static TEvent *out;
static TEvent queue[QUEUE_LEN];
static TPoint where;		/* mouse coordinates */
static fd_set set;		/* used for select() */
static int do_repaint;		/* should redraw the screen ? */
static int do_resize;		/* resize screen ? */
static int length;		/* number of events in the queue */
static int ms_fd;		/* mouse file descriptor */
static int ms_oldbuttons;	/* mouse button status */
static int timeout_auto;	/* time when generate next cmMouseAuto */
static int timeout_esc;		/* time limit to detect Esc-key sequences */
static int timeout_wakeup;	/* time when generate next cmWakeup */
static int timer_value;		/* current timer value */
static int vcs_fd;		/* virtual console system descriptor */

inline int range(int test, int min, int max)
{
	return test < min ? min : test > max ? max : test;
}

inline void safeput(char *&p, char *cap)
{
	if (cap != NULL) while (*cap != '\0') *p++ = *cap++;
}

static void startcurses()
{
	initscr();
	keypad(stdscr, TRUE);
	cbreak();
	noecho();
	setupterm(0, STDOUT_FILENO, 0);
	timeout(0);	/* set getch() in non-blocking mode */
}

static void stopcurses()
{
	char out[4096], *p = out;

	safeput(p, clear_screen);
	write(STDOUT_FILENO, out, p - out);
	endwin();
}

/*
 * TScreen constructor.
 */

TScreen::TScreen()
{
	/* acquire screen size */

	winsize win;
	ioctl(STDIN_FILENO, TIOCGWINSZ, &win);
	if (win.ws_col > 0 && win.ws_row > 0)
	{
		screenWidth = win.ws_col;
		screenHeight = win.ws_row;
	}
	else
	{
		LOG("unable to detect screen size");
		screenWidth = 80;
		screenHeight = 25;
	}
	LOG("screen is " << (int) screenWidth << "x" << (int) screenHeight);
	screenBuffer = new ushort[screenWidth * screenHeight];

	/* curses stuff */

	startcurses();

	/* gpm stuff */

	Gpm_Connect conn;
	conn.eventMask = ~0;		/* I want all events */
	conn.defaultMask = 0;		/* no default treatment */
	conn.maxMod = ~0;
	conn.minMod = 0;
	gpm_zerobased = 1;		/* coordinates start from zero */
	if ((ms_fd = Gpm_Open(&conn, 0)) < 0)
	{
		LOG("no Gpm, running without mouse");
	}
	else LOG("Gpm server version " << Gpm_GetServerVersion(NULL));
	where.x = where.y = ms_oldbuttons = 0;

	/* vcs stuff */

	vcs_fd = -1;
	char *term;
	if ((term = ttyname(STDOUT_FILENO)) != NULL)
	{
		LOG("you are connected in " << term);
		if (memcmp(term, "/dev/tty", 8) == 0)
		{
			char *tail, *test = term + 8;

			/*
			 * terminals like tty1 are system console, others like
			 * ttyS1 or ttyp1 are remote connections, so if
			 * conversion fails we are running remotely
			 */
			int console_no = strtol(test, &tail, 10);
			if (test != tail)	/* conversion ok */
			{
				char dev[PATH_MAX];

				sprintf(dev, "/dev/vcsa%d", console_no);
				if ((vcs_fd = open(dev, O_WRONLY)) < 0)
				{
					LOG("unable to open " << dev);
				}
			}
		}
	}
	screenMode = vcs_fd >= 0 ? smCO80 : smMono;

	/* internal stuff */

	in = out = &queue[0];
	do_repaint = do_resize = length = 0;
	timeout_auto = timeout_esc = -1;
	timeout_wakeup = timer_value = 0;

	/* setup file descriptors */

	FD_ZERO(&set);
	FD_SET(STDIN_FILENO, &set);
	if (ms_fd >= 0) FD_SET(ms_fd, &set);

	/* catch useful signals */

	signal(SIGALRM, sigHandler);
	signal(SIGCONT, sigHandler);
	signal(SIGTSTP, sigHandler);
	signal(SIGWINCH, sigHandler);

	/* generates a SIGALRM signal every DELAY_SIGALRM ms */

	struct itimerval timer;
	timer.it_interval.tv_usec = timer.it_value.tv_usec =
		DELAY_SIGALRM * 1000;
	timer.it_interval.tv_sec = timer.it_value.tv_sec = 0;
	setitimer(ITIMER_REAL, &timer, NULL);
}

/*
 * TScreen destructor.
 */

TScreen::~TScreen()
{
	stopcurses();
	if (ms_fd >= 0) Gpm_Close();
	if (vcs_fd >= 0) close(vcs_fd);
	delete[] screenBuffer;
	LOG("terminated");
}

void TScreen::resume()
{
	startcurses();
	do_repaint++;
}

void TScreen::suspend()
{
	stopcurses();
}

/*
 * Gets an event from the queue.
 */

void TScreen::getEvent(TEvent &event)
{
	event.what = evNothing;
	if (length > 0)		/* handles pending events */
	{
		length--;
		event = *out;
		if (++out == &queue[QUEUE_LEN]) out = &queue[0];
	}
	else if (do_repaint)
	{
		do_repaint = 0;
		event.message.command = cmLinuxRepaint;
		event.what = evCommand;

		/* invalidate video buffer */

		if (vcs_fd < 0) memset(screenBuffer, 0,
			screenWidth * screenHeight * sizeof(ushort));
	}
	else if (do_resize)
	{
		winsize win;

		do_resize = 0;
		ioctl(STDIN_FILENO, TIOCGWINSZ, &win);
		screenWidth = range(win.ws_col, 4, 132);
		screenHeight = range(win.ws_row, 4, 80);
		delete[] screenBuffer;
		screenBuffer = new ushort[screenWidth * screenHeight];
		event.message.command = cmLinuxResize;
		event.what = evCommand;

		/* invalidate video buffer */

		if (vcs_fd < 0) memset(screenBuffer, 0,
			screenWidth * screenHeight * sizeof(ushort));
	}
	else if (timeout_auto != -1 && timer_value >= timeout_auto)
	{
		timeout_auto = timer_value + DELAY_MOUSEAUTO_NEXT;
		event.mouse.buttons = ms_oldbuttons;
		event.what = evMouseAuto;
	}
	else if (timer_value >= timeout_wakeup)
	{
		timeout_wakeup = timer_value + DELAY_WAKEUP;
		event.message.command = cmLinuxWakeup;
		event.what = evCommand;
	}
	else
	{
		fd_set ready = set;
		int kbReady = 0;

		/*
		 * suspend until there is a signal or some data in file
		 * descriptors
		 */
		if (select(FD_SETSIZE, &ready, NULL, NULL, NULL) > 0)
		{
			kbReady = FD_ISSET(STDIN_FILENO, &ready);
			if (ms_fd >= 0 && FD_ISSET(ms_fd, &ready))
			{
				Gpm_Event mev;

				Gpm_GetEvent(&mev);
				msHandle(&mev);
			}
		}
		if (kbReady || timeout_esc != -1) kbHandle();
	}
}

/*
 * Generates a beep.
 */

void TScreen::makeBeep()
{
	char out[4096], *p = out;

	safeput(p, bell);
	write(STDOUT_FILENO, out, p - out);
}

/*
 * Puts an event in the queue.  If the queue is full the event will be
 * discarded.
 */

void TScreen::putEvent(TEvent &event)
{
	if (length < QUEUE_LEN)
	{
		length++;
		*in = event;
		if (++in == &queue[QUEUE_LEN]) in = &queue[0];
	}
}

/*
 * General signal handler.
 */

void TScreen::sigHandler(int signo)
{
	switch (signo)
	{
	case SIGALRM:
		/*
		 * called every DELAY_SIGALRM ms
		 */
		signal(SIGALRM, sigHandler);
		timer_value += DELAY_SIGALRM;
		break;
	case SIGCONT:
		/*
		 * called when the user restart the process after a ctrl-z
		 */
		LOG("continuing process");
		TScreen::resume();
		signal(SIGCONT, sigHandler);
		signal(SIGTSTP, sigHandler);
		break;
	case SIGTSTP:
		/*
		 * called when the user presses ctrl-z
		 */
		TScreen::suspend();
		LOG("process stopped, type 'fg' to resume");
		signal(SIGTSTP, SIG_DFL);	/* use default handler */
		raise(SIGTSTP);		/* stop the process */
		break;
	case SIGWINCH:
		signal(SIGWINCH, sigHandler);
		do_resize++;
	}
}

/*
 * Reads a key from the keyboard.
 */

void TScreen::kbHandle()
{
	int code, type = 0;

	/* see if there is data available */

	if ((code = getch()) != ERR && code != KEY_MOUSE)
	{
		/* grab the escape key and start the timer */

		if (timeout_esc == -1 && code == 27)
		{
			timeout_esc = timer_value + DELAY_ESCAPE;
			return;
		}

		/* key pressed within time limit */

		if (timeout_esc != -1 && timer_value <= timeout_esc)
		{
			timeout_esc = -1;
			if (code != 27)		/* simulate Alt-letter code */
			{
				code = toupper(code);
				type = TALT;
			}
		}
	}
	else if (timeout_esc != -1 && timer_value >= timeout_esc)
	{
		/* timeout condition: generate standard Esc code */

		timeout_esc = -1;
		code = 27;
	}
	else return;	/* nothing to do */

	int modifiers = kbReadShiftState();
	if ((code = kbMapKey(code, type, modifiers)) != kbNoKey)
	{
		TEvent event;

		event.what = evKeyDown;
		event.keyDown.keyCode = code;
		event.keyDown.controlKeyState = modifiers;
		putEvent(event);
	}
}

/*
 * Builds a keycode from code and modifiers.
 */

int TScreen::kbMapKey(int code, int type, int modifiers)
{
	keymap_t *best = NULL, *p;

	for (p = keymap; p < keymap + sizeof(keymap) / sizeof(keymap_t); p++)
	{
		/* code and type must match */

		if (p->in == code && p->type == type)
		{
			/*
			 * now get the best keycode we have, modifier keys
			 * may differ
			 */
			if (best == NULL || p->modifiers == modifiers)
			{
				best = p;
			}
		}
	}
	if (best != NULL) return best->out;	/* keycode found */
	if (code <= 255) return code;	/* it is an ascii character */
	return kbNoKey;
}

/*
 * Gets information about modifier keys (Alt, Ctrl and Shift).  This can
 * be done only if the program runs on the system console.
 */

int TScreen::kbReadShiftState()
{
	int arg = 6;	/* TIOCLINUX function #6 */
	int shift = 0;

	if (ioctl(STDIN_FILENO, TIOCLINUX, &arg) != -1)
	{
		if (arg & (2 | 8)) shift |= kbLeftAlt | kbRightAlt;
		if (arg & 4) shift |= kbLeftCtrl | kbRightCtrl;
		if (arg & 1) shift |= kbLeftShift | kbRightShift;
	}
	return shift;
}

/*
 * Mouse handler called by Gpm_Getchar().
 */

void TScreen::msHandle(Gpm_Event *mev)
{
	TEvent event;

	event.mouse.controlKeyState = kbReadShiftState();
	event.mouse.where.x = range(mev->x, 0, screenWidth - 1);
	event.mouse.where.y = range(mev->y, 0, screenHeight - 1);
	if (mev->type & GPM_DOUBLE && mev->type & GPM_UP)
	{
		event.mouse.buttons = ms_oldbuttons;
		event.mouse.eventFlags = meDoubleClick;
		event.what = evMouseDown;
		msPut(event);
	}
	if (mev->type & (GPM_DRAG | GPM_MOVE))
	{
		if (event.mouse.where != where)
		{
			event.mouse.buttons = mev->buttons;
			event.mouse.eventFlags = meMouseMoved;
			event.what = evMouseMove;
			msPut(event);

			/* save mouse status */

			ms_oldbuttons = mev->buttons;
			timeout_auto = -1;

			/* redraw the mouse in the new place */

			scDrawMouse(0);
			where = event.mouse.where;
			scDrawMouse(1);
		}
	}
	if (mev->type & GPM_DOWN)
	{
		event.mouse.buttons = mev->buttons & ~ms_oldbuttons;
		event.mouse.eventFlags = 0;
		event.what = evMouseDown;
		msPut(event);

		/* save mouse status */

		ms_oldbuttons = mev->buttons;
		timeout_auto = timer_value + DELAY_MOUSEAUTO_FIRST;
	}
	if (mev->type & GPM_UP)
	{
		event.mouse.buttons = mev->buttons;
		event.mouse.eventFlags = 0;
		event.what = evMouseUp;
		msPut(event);

		/* save mouse status */

		ms_oldbuttons &= ~mev->buttons;
		timeout_auto = -1;
	}
}

/*
 * Store mouse event.
 */

void TScreen::msPut(TEvent &event)
{
	if (event.mouse.buttons != 0)
	{
		int b = 0;

		if (event.mouse.buttons & GPM_B_LEFT) b |= mbLeftButton;
		if (event.mouse.buttons & GPM_B_RIGHT) b |= mbRightButton;
		if (TEventQueue::mouseReverse == True && b != 0 && b != 3)
		{
			b ^= 3;
		}
		event.mouse.buttons = b;
	}
	putEvent(event);
}

/*
 * Hides or shows the mouse pointer.
 */

void TScreen::scDrawMouse(int show)
{
	if (ms_fd < 0) return;

	int addr = screenWidth * where.y + where.x;
	ushort cell = screenBuffer[addr];
	if (vcs_fd < 0)		/* standard out */
	{
		char out[4096], *p = out;
		int col = cell >> 8;

		if (show)
		{
			if (col == 0x0f || col == 0x07) safeput(p,
				enter_reverse_mode);
		}
		else
		{
			if (col == 0x0f) safeput(p, enter_bold_mode);
			else if (col == 0x70) safeput(p, enter_reverse_mode);
		}
		safeput(p, save_cursor);
		safeput(p, tparm(cursor_address, where.y, where.x));
		*p++ = pctoascii[cell & 0xff];
		safeput(p, restore_cursor);
		safeput(p, exit_attribute_mode);
		write(STDOUT_FILENO, out, p - out);
	}
	else	/* use vcs */
	{
		if (show) cell ^= 0x7f00;
		lseek(vcs_fd, addr * sizeof(ushort) + 4, SEEK_SET);
		write(vcs_fd, &cell, sizeof(ushort));
	}
}

/*
 * Moves the cursor to another place.
 */

void TScreen::scMoveCursor(int x, int y)
{
	if (vcs_fd < 0)		/* standard out */
	{
		char out[4096], *p = out;

		safeput(p, tparm(cursor_address, y, x));
		write(STDOUT_FILENO, out, p - out);
	}
	else	/* use vcs */
	{
		unsigned char where[2] = {x, y};

		lseek(vcs_fd, 2, SEEK_SET);
		write(vcs_fd, where, sizeof(where));
	}
}

/*
 * Draws a line of text on the screen.
 */

void TScreen::scWriteRow(int dst, ushort *src, int len)
{
	if (vcs_fd < 0)		/* standard out */
	{
		ushort *old = screenBuffer + dst;
		ushort *old_right = old + len - 1;
		ushort *src_right = src + len - 1;

		/* remove unchanged characters from left to right */

		while (len > 0 && *old == *src)
		{
			dst++;
			len--;
			old++;
			src++;
		}

		/* remove unchanged characters from right to left */

		while (len > 0 && *old_right == *src_right)
		{
			len--;
			old_right--;
			src_right--;
		}

		/* write only middle changed characters */

		if (len > 0)
		{
			char out[4096], *p = out;
			int col = -1;

			safeput(p, save_cursor);
			safeput(p, tparm(cursor_address, dst / screenWidth,
				dst % screenWidth));
			for (; len > 0; len--, src++)
			{
				int newcol = *src >> 8;

				*old++ = *src;
				if (col == -1 || col != newcol)
				{
					col = newcol;
					safeput(p, exit_attribute_mode);
					if (col == 0x0f) safeput(p,
						enter_bold_mode);
					else if (col == 0x70) safeput(p,
						enter_reverse_mode);
				}
				*p++ = pctoascii[*src & 0xff];
			}
			safeput(p, restore_cursor);
			safeput(p, exit_attribute_mode);
			write(STDOUT_FILENO, out, p - out);
		}
	}
	else	/* use vcs */
	{
		lseek(vcs_fd, dst * sizeof(ushort) + 4, SEEK_SET);
		write(vcs_fd, src, len * sizeof(ushort));
	}
}

/*
 * Returns the length of a file.
 */

long int filelength(int fd)
{
	long int save = lseek(fd, 0, SEEK_CUR);
	long int len = lseek(fd, 0, SEEK_END);

	lseek(fd, save, SEEK_SET);
	return len;
}

/*
 * Expands a path into its directory and file components.
 */

void expandPath(const char *path, char *dir, char *file)
{
	char *tag = strrchr(path, '/');

	/* the path is in the form /dir1/dir2/file ? */

	if (tag != NULL)
	{
		strcpy(file, tag + 1);
		strncpy(dir, path, tag - path + 1);
		dir[tag - path + 1] = '\0';
	}
	else
	{
		/* there is only the file name */

		strcpy(file, path);
		dir[0] = '\0';
	}
}

void fexpand(char *path)
{
	char dir[PATH_MAX];
	char file[PATH_MAX];
	char oldPath[PATH_MAX];

	expandPath(path, dir, file);
	getcwd(oldPath, sizeof(oldPath));
	chdir(dir);
	getcwd(dir, sizeof(dir));
	chdir(oldPath);
	if (strcmp(dir, "/") == 0) sprintf(path, "/%s", file);
	else sprintf(path, "%s/%s", dir, file);
}
