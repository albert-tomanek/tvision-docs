/*
 * TObject.cc
 *
 * Turbo Vision - Version 2.0
 *
 * Copyright (c) 1994 by Borland International
 * All Rights Reserved.
 *
 * Modified by Sergio Sigala <ssigala@globalnet.it>
 */

#define Uses_TObject
#include <tvision/tv.h>

TObject::~TObject()
{
}

void TObject::shutDown()
{
}
