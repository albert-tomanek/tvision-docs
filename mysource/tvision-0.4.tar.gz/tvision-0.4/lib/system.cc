/*
 * system.cc
 *
 * Copyright (c) 1997 Sergio Sigala, Brescia, Italy.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#define Uses_TDrawBuffer
#define Uses_TEvent
#define Uses_TEventQueue
#define Uses_TKeys
#define Uses_TScreen
#include <tvision/tv.h>

#include <ctype.h>
#include <fcntl.h>
#include <iostream.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#ifdef __FreeBSD__
	/* #include <machine/console.h> */
	#define CONS_MOUSECTL	_IOWR('c', 10, mouse_info_t)
	#define	RIGHT_BUTTON		0x01
	#define	MIDDLE_BUTTON		0x02
	#define	LEFT_BUTTON		0x04
	struct mouse_data {
		int	x;
		int 	y;
		int 	buttons;
	};
	struct mouse_mode {
		int	mode;
		int	signal;
	};
	#define MOUSE_SHOW		0x01
	#define MOUSE_HIDE		0x02
	#define MOUSE_MOVEABS		0x03
	#define MOUSE_MOVEREL		0x04
	#define MOUSE_GETINFO		0x05
	#define MOUSE_MODE		0x06
	#define MOUSE_ACTION		0x07
	struct mouse_info {
		int	operation;
		union {
			struct mouse_data data;
			struct mouse_mode mode;
		}u;
	};
	typedef struct mouse_info mouse_info_t;
	#include <ncurses.h>
	#define __USE_FBSDM	/* use FreeBSD mouse interface */
#elif defined(__linux__)
	#include <curses.h>
	extern "C"
	{
	#include <gpm.h>
	};
	#include <sys/kd.h>
	#define __USE_GPM	/* use gpm if possible */
	#define __USE_VCS	/* use vcs if possible */
#else
	#include <curses.h>
#endif

#include <term.h>
#undef buttons		/* delete this line and see what happens :-) */

/*
 * This is the delay in ms before the first evMouseAuto is generated when the
 * user holds down a mouse button.
 */
#define DELAY_AUTOCLICK_FIRST	400

/*
 * This is the delay in ms between next evMouseAuto events.  Must be greater
 * than DELAY_SIGALRM (see below).
 */
#define DELAY_AUTOCLICK_NEXT	100

/*
 * This is the time limit in ms within button presses are recognized as
 * double-click events.  Used only under FreeBSD because Gpm has its own
 * double-click detecting machanism.
 */
#define DELAY_DOUBLECLICK	300

/*
 * This is the time limit in ms within Esc-key sequences are detected as
 * Alt-letter sequences.  Useful when we can't generate Alt-letter sequences
 * directly.
 */
#define DELAY_ESCAPE		400

/*
 * This is the delay in ms between consecutive SIGALRM signals.  This
 * signal is used to generate evMouseAuto and cmSysWakeup events.
 */
#define DELAY_SIGALRM		100

/*
 * This broadcast event is used to update the StatusLine.
 */
#define DELAY_WAKEUP		200

/*
 * FreeBSD mouse system only: define which signal to use.
 */
#define FBSDM_SIGNAL		SIGUSR1

/*
 * This sets the size of the internal event queue.
 */
#define QUEUE_LEN		8

/*
 * Define this only if your terminals understand save_cursor and
 * restore_cursor strings.
 */
/* #define __SAVECURSOR_OK */

#ifdef __linux__
extern char *program_invocation_short_name;
#define LOG(s) cerr << program_invocation_short_name << ": " << s << "\n"
#else
#define LOG(s) cerr << __FILE__": " << s << "\n"
#endif

/* key modifiers */

#define MALT		(kbLeftAlt | kbRightAlt)
#define MCTRL		(kbLeftCtrl | kbRightCtrl)
#define MSHIFT		(kbLeftShift | kbRightShift)

/* key types */

#define TALT		0x01		/* alt-letter key */

typedef struct
{
	int in;
	char type;
	char modifiers;
	short out;
}
keym_t;

static keym_t keym[] =
{
	/* ascii codes */

	1, 0, 0, kbCtrlA, 2, 0, 0, kbCtrlB, 3, 0, 0, kbCtrlC,
	4, 0, 0, kbCtrlD, 5, 0, 0, kbCtrlE, 6, 0, 0, kbCtrlF,
	7, 0, 0, kbCtrlG, 8, 0, 0, kbCtrlH, 9, 0, 0, kbCtrlI,
	10, 0, 0, kbCtrlJ, 11, 0, 0, kbCtrlK, 12, 0, 0, kbCtrlL,
	13, 0, 0, kbCtrlM, 14, 0, 0, kbCtrlN, 15, 0, 0, kbCtrlO,
	16, 0, 0, kbCtrlP, 17, 0, 0, kbCtrlQ, 18, 0, 0, kbCtrlR,
	19, 0, 0, kbCtrlS, 20, 0, 0, kbCtrlT, 21, 0, 0, kbCtrlU,
	22, 0, 0, kbCtrlV, 23, 0, 0, kbCtrlW, 24, 0, 0, kbCtrlX,
	25, 0, 0, kbCtrlY, 26, 0, 0, kbCtrlZ, 9, 0, 0, kbTab,
	10, 0, 0, kbEnter, 27, 0, 0, kbEsc, 31, 0, 0, kbCtrlBack,
	127, 0, 0, kbBack,

	9, 0, MSHIFT, kbShiftTab,

	/* alt-letter codes */

	' ', TALT, 0, kbAltSpace,
	'0', TALT, 0, kbAlt0, '1', TALT, 0, kbAlt1, '2', TALT, 0, kbAlt2,
	'3', TALT, 0, kbAlt3, '4', TALT, 0, kbAlt4, '5', TALT, 0, kbAlt5,
	'6', TALT, 0, kbAlt6, '7', TALT, 0, kbAlt7, '8', TALT, 0, kbAlt8,
	'9', TALT, 0, kbAlt9,
	'A', TALT, 0, kbAltA, 'B', TALT, 0, kbAltB, 'C', TALT, 0, kbAltC,
	'D', TALT, 0, kbAltD, 'E', TALT, 0, kbAltE, 'F', TALT, 0, kbAltF,
	'G', TALT, 0, kbAltG, 'H', TALT, 0, kbAltH, 'I', TALT, 0, kbAltI,
	'J', TALT, 0, kbAltJ, 'K', TALT, 0, kbAltK, 'L', TALT, 0, kbAltL,
	'M', TALT, 0, kbAltM, 'N', TALT, 0, kbAltN, 'O', TALT, 0, kbAltO,
	'P', TALT, 0, kbAltP, 'Q', TALT, 0, kbAltQ, 'R', TALT, 0, kbAltR,
	'S', TALT, 0, kbAltS, 'T', TALT, 0, kbAltT, 'U', TALT, 0, kbAltU,
	'V', TALT, 0, kbAltV, 'W', TALT, 0, kbAltW, 'X', TALT, 0, kbAltX,
	'Y', TALT, 0, kbAltY, 'Z', TALT, 0, kbAltZ, 127, TALT, 0, kbAltBack,

	/* escape codes */

	KEY_DOWN, 0, 0, kbDown, KEY_UP, 0, 0, kbUp, KEY_LEFT, 0, 0, kbLeft,
	KEY_RIGHT, 0, 0, kbRight, KEY_HOME, 0, 0, kbHome,
	KEY_BACKSPACE, 0, 0, kbBack, KEY_F(1), 0, 0, kbF1,
	KEY_F(2), 0, 0, kbF2, KEY_F(3), 0, 0, kbF3, KEY_F(4), 0, 0, kbF4,
	KEY_F(5), 0, 0, kbF5, KEY_F(6), 0, 0, kbF6, KEY_F(7), 0, 0, kbF7,
	KEY_F(8), 0, 0, kbF8, KEY_F(9), 0, 0, kbF9, KEY_F(10), 0, 0, kbF10,
	KEY_DC, 0, 0, kbDel, KEY_IC, 0, 0, kbIns, KEY_NPAGE, 0, 0, kbPgDn,
	KEY_PPAGE, 0, 0, kbPgUp, KEY_END, 0, 0, kbEnd,

	KEY_LEFT, 0, MCTRL, kbCtrlLeft, KEY_RIGHT, 0, MCTRL, kbCtrlRight,
	KEY_HOME, 0, MCTRL, kbCtrlHome, KEY_F(1), 0, MCTRL, kbCtrlF1,
	KEY_F(2), 0, MCTRL, kbCtrlF2, KEY_F(3), 0, MCTRL, kbCtrlF3,
	KEY_F(4), 0, MCTRL, kbCtrlF4, KEY_F(5), 0, MCTRL, kbCtrlF5,
	KEY_F(6), 0, MCTRL, kbCtrlF6, KEY_F(7), 0, MCTRL, kbCtrlF7,
	KEY_F(8), 0, MCTRL, kbCtrlF8, KEY_F(9), 0, MCTRL, kbCtrlF9,
	KEY_F(10), 0, MCTRL, kbCtrlF10, KEY_DC, 0, MCTRL, kbCtrlDel, 
	KEY_IC, 0, MCTRL, kbCtrlIns, KEY_NPAGE, 0, MCTRL, kbCtrlPgDn,
	KEY_PPAGE, 0, MCTRL, kbCtrlPgUp, KEY_END, 0, MCTRL, kbCtrlEnd,

	KEY_F(11), 0, MSHIFT, kbShiftF1, KEY_F(12), 0, MSHIFT, kbShiftF2,
	KEY_F(13), 0, MSHIFT, kbShiftF3, KEY_F(14), 0, MSHIFT, kbShiftF4,
	KEY_F(15), 0, MSHIFT, kbShiftF5, KEY_F(16), 0, MSHIFT, kbShiftF6,
	KEY_F(17), 0, MSHIFT, kbShiftF7, KEY_F(18), 0, MSHIFT, kbShiftF8,
	KEY_F(19), 0, MSHIFT, kbShiftF9, KEY_F(20), 0, MSHIFT, kbShiftF10,
	KEY_DC, 0, MSHIFT, kbShiftDel, KEY_IC, 0, MSHIFT, kbShiftIns
};

/* lookup table to translate characters from pc set to standard ascii */

static unsigned char pcToAscii[] =
{
	" OOooooooooo!!!*><|!!O_|^V><--^V !\"#$%&'()*+,-./0123456789:;<=>?"
	"@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~d"
	"cueaaaaceeeiiiaaeafooouuyOUcLYPfaiounN--?--//!<>:%%|{+++++I+'++."
	"`++}-+++`.+++=+++++++++++'.|-||-abipeouyooooooEn=+><()-=o..Vn2X "
};

ushort TEventQueue::doubleDelay = 8;
Boolean TEventQueue::mouseReverse = False;

ushort TScreen::screenMode;
uchar TScreen::screenWidth;
uchar TScreen::screenHeight;
ushort *TScreen::screenBuffer;

static TEvent *evIn;		/* message queue system */
static TEvent *evOut;
static TEvent evQueue[QUEUE_LEN];
static fd_set fdSet;		/* used for select() */
static int currentTime;		/* current timer value */
static int doRepaint;		/* should redraw the screen ? */
static int doResize;		/* resize screen ? */
static int evLength;		/* number of events in the queue */

enum { PAL_MONO, PAL_LOW, PAL_HIGH };
static int palette;			/* current palette */

/*
 * A simple class which implements a timer.
 */

class Timer
{
	int limit;
public:
	Timer() { limit = -1; }
	int isExpired() { return limit != -1 && currentTime >= limit; }
	int isRunning() { return limit != -1; }
	void start(int timeout) { limit = currentTime + timeout; }
	void stop() { limit = -1; }
};

static Timer kbEscTimer;	/* time limit to detect Esc-key sequences */
static Timer wakeupTimer;	/* time when generate next cmWakeup */

#ifdef __FreeBSD__
static int usePcChars;
#endif

#ifndef __SAVECURSOR_OK
static int curX, curY;		/* saved cursor coordinates */
#endif

#ifdef __USE_FBSDM
static TPoint msWhere;		/* mouse coordinates */
static Timer msAutoTimer;	/* time when generate next cmMouseAuto */
static Timer msDoubleTimer;	/* time limit to detect double-click events */
static int msFlag;		/* set if there are mouse events */
static int msOldButtons;	/* mouse button status */
static int msUseArrow;		/* use arrow pointer */
#endif

#ifdef __USE_GPM
static TPoint msWhere;		/* mouse coordinates */
static Timer msAutoTimer;	/* time when generate next cmMouseAuto */
static int msFd;		/* mouse file descriptor */
static int msOldButtons;	/* mouse button status */
#endif

#ifdef __USE_VCS
static int vcsFd;		/* virtual console system descriptor */
#endif

/*
 * GENERAL FUNCTIONS
 */

inline int range(int test, int min, int max)
{
	return test < min ? min : test > max ? max : test;
}

inline void safeput(char *&p, char *cap)
{
	if (cap != NULL) while (*cap != '\0') *p++ = *cap++;
}

/*
 * KEYBOARD FUNCTIONS
 */

/*
 * Builds a keycode from code and modifiers.
 */

static int kbMapKey(int code, int type, int modifiers)
{
	keym_t *best = NULL, *p;

	for (p = keym; p < keym + sizeof(keym) / sizeof(keym_t); p++)
	{
		/* code and type must match */

		if (p->in == code && p->type == type)
		{
			/*
			 * now get the best keycode we have, modifier keys
			 * may differ
			 */
			if (best == NULL || p->modifiers == modifiers)
			{
				best = p;
			}
		}
	}
	if (best != NULL) return best->out;	/* keycode found */
	if (code <= 255) return code;	/* it is an ascii character */
	return kbNoKey;		/* unknown code */
}

/*
 * Gets information about modifier keys (Alt, Ctrl and Shift).  This can
 * be done only if the program runs on the system console.
 */

static int kbReadShiftState()
{
#ifdef __linux__
	int arg = 6;	/* TIOCLINUX function #6 */
	int shift = 0;

	if (ioctl(STDIN_FILENO, TIOCLINUX, &arg) != -1)
	{
		if (arg & (2 | 8)) shift |= kbLeftAlt | kbRightAlt;
		if (arg & 4) shift |= kbLeftCtrl | kbRightCtrl;
		if (arg & 1) shift |= kbLeftShift | kbRightShift;
	}
	return shift;
#else
	return 0;
#endif
}

/*
 * Reads a key from the keyboard.
 */

static void kbHandle()
{
	int code, type = 0;

	/* see if there is data available */

#ifdef NCURSES_MOUSE_VERSION
	if ((code = getch()) != ERR && code != KEY_MOUSE)
#else
	if ((code = getch()) != ERR)
#endif
	{
		/* grab the escape key and start the timer */

		if (code == 27 && !kbEscTimer.isRunning())
		{
			kbEscTimer.start(DELAY_ESCAPE);
			return;
		}

		/* key pressed within time limit */

		if (kbEscTimer.isRunning() && !kbEscTimer.isExpired())
		{
			kbEscTimer.stop();
			if (code != 27)		/* simulate Alt-letter code */
			{
				code = toupper(code);
				type = TALT;
			}
		}
	}
	else if (kbEscTimer.isExpired())
	{
		/* timeout condition: generate standard Esc code */

		kbEscTimer.stop();
		code = 27;
	}
	else return;	/* nothing to do */

	int modifiers = kbReadShiftState();
	if ((code = kbMapKey(code, type, modifiers)) != kbNoKey)
	{
		TEvent event;

		event.what = evKeyDown;
		event.keyDown.keyCode = code;
		event.keyDown.controlKeyState = modifiers;
		TScreen::putEvent(event);
	}
}

/*
 * MOUSE FUNCTIONS
 */

/*
 * This function inserts a mouse event in the event queue after adjusting the
 * `event.mouse.buttons' field.
 */

#if defined(__USE_FBSDM) || defined(__USE_GPM)
static void msPutEvent(TEvent &event, int buttons, int flags, int what)
{
	event.mouse.buttons = 0;
	event.mouse.eventFlags = flags;
	event.what = what;
	if (buttons != 0)
	{
		int leftKey = mbLeftButton;
		int rightKey = mbRightButton;

		if (TEventQueue::mouseReverse)	/* swap buttons ? */
		{
			leftKey = mbRightButton;
			rightKey = mbLeftButton;
		}
#ifdef __USE_FBSDM
		if (buttons & LEFT_BUTTON) event.mouse.buttons |= leftKey;
		if (buttons & RIGHT_BUTTON) event.mouse.buttons |= rightKey;
#elif defined(__USE_GPM)
		if (buttons & GPM_B_LEFT) event.mouse.buttons |= leftKey;
		if (buttons & GPM_B_RIGHT) event.mouse.buttons |= rightKey;
#endif
	}
	TScreen::putEvent(event);
}
#endif

/*
 * Initializes the FreeBSD mouse.  The mouse is handled by the kernel.  We
 * control it with ioctl(...) calls.
 */

#ifdef __USE_FBSDM
static void fbsdmInit(char *env)
{
	mouse_info_t mi;

	msAutoTimer.stop();
	msDoubleTimer.stop();
	msFlag = msOldButtons = 0;
	msUseArrow = strstr(env, "noarrow") == NULL;
	if (!msUseArrow) LOG("arrow pointer suppressed");
	mi.operation = MOUSE_MODE;
	mi.u.mode.signal = FBSDM_SIGNAL;
	if (ioctl(STDOUT_FILENO, CONS_MOUSECTL, &mi) < 0)
	{
		LOG("unable to use the mouse");
	}
	mi.operation = MOUSE_GETINFO;
	ioctl(STDOUT_FILENO, CONS_MOUSECTL, &mi);
	msWhere.x = range(mi.u.data.x / 8, 0, TScreen::screenWidth - 1);
	msWhere.y = range(mi.u.data.y / 16, 0, TScreen::screenHeight - 1);
}

/*
 * Closes the FreeBSD mouse.
 */

static void fbsdmClose()
{
	mouse_info_t mi;

	mi.operation = MOUSE_MODE;
	mi.u.mode.signal = 0;
	ioctl(STDOUT_FILENO, CONS_MOUSECTL, &mi);
}

/*
 * Checks the status of every button and generates the related event.
 */

static void fbsdmProcessButton(TEvent &event, int buttons, int mask)
{
	/* is button pressed ? */

	if (buttons & mask)
	{
		msAutoTimer.start(DELAY_AUTOCLICK_FIRST);
		if (msDoubleTimer.isRunning() && !msDoubleTimer.isExpired())
		{
			msDoubleTimer.stop();
			msPutEvent(event, mask, meDoubleClick, evMouseDown);
		}
		else
		{
			msDoubleTimer.start(DELAY_DOUBLECLICK);
			msPutEvent(event, mask, 0, evMouseDown);
		}
	}
	else	/* button is released */
	{
		msAutoTimer.stop();
		msPutEvent(event, mask, 0, evMouseUp);
	}
}

/*
 * Handles events from the FreeBSD mouse driver.
 */

static void fbsdmHandle()
{
	TEvent event;
	mouse_info_t mi;

	mi.operation = MOUSE_GETINFO;
	ioctl(STDOUT_FILENO, CONS_MOUSECTL, &mi);
	event.mouse.controlKeyState = kbReadShiftState();
	event.mouse.where.x = range(mi.u.data.x / 8, 0,
		TScreen::screenWidth - 1);
	event.mouse.where.y = range(mi.u.data.y / 16, 0,
		TScreen::screenHeight - 1);
	if (event.mouse.where != msWhere)
	{
		msAutoTimer.stop();
		msDoubleTimer.stop();
		msPutEvent(event, mi.u.data.buttons, meMouseMoved,
			evMouseMove);
		msOldButtons = mi.u.data.buttons;

		/* redraw the mouse in the new place */

		if (msUseArrow) msWhere = event.mouse.where;
		else
		{
			TScreen::drawMouse(0);
			msWhere = event.mouse.where;
			TScreen::drawMouse(1);
		}
	}
	if (mi.u.data.buttons != msOldButtons)
	{
		int changed = mi.u.data.buttons ^ msOldButtons;
		int i;
		static int mask[] = { LEFT_BUTTON, RIGHT_BUTTON };

		/* check for pressed or released buttons */

		for (i = 0; i < 2; i++) if (changed & mask[i])
		{
			fbsdmProcessButton(event, mi.u.data.buttons, mask[i]);
		}
		msOldButtons = mi.u.data.buttons;
	}
}
#endif

/*
 * Opens the connection.
 */

#ifdef __USE_GPM
static void gpmInit(char *env)
{
	msAutoTimer.stop();
	msFd = -1;
	msOldButtons = msWhere.x = msWhere.y = 0;
	if (strstr(env, "nogpm") != NULL) LOG("gpm support disabled");
	else
	{
		Gpm_Connect conn;

		conn.eventMask = ~0;	/* I want all events */
		conn.defaultMask = 0;	/* no default treatment */
		conn.maxMod = ~0;
		conn.minMod = 0;
		gpm_zerobased = 1;	/* coordinates start from zero */
		if ((msFd = Gpm_Open(&conn, 0)) < 0)
		{
			LOG("no gpm, running without mouse");
		}
		else
		{
			LOG("gpm server " << Gpm_GetServerVersion(NULL));
			FD_SET(msFd, &fdSet);
		}
	}
}

/*
 * Closes the connection.
 */

static void gpmClose()
{
	if (msFd >= 0)
	{
		Gpm_Close();
		FD_CLR(msFd, &fdSet);
	}
}

/*
 * Handles mouse events.
 */

static void gpmHandle()
{
	Gpm_Event me;
	TEvent event;

	Gpm_GetEvent(&me);
	event.mouse.controlKeyState = kbReadShiftState();
	event.mouse.where.x = range(me.x, 0, TScreen::screenWidth - 1);
	event.mouse.where.y = range(me.y, 0, TScreen::screenHeight - 1);
	if (me.type & GPM_DOUBLE)
	{
		if (me.type & GPM_DOWN) return;
		if (me.type & GPM_UP)
		{
			msAutoTimer.stop();
			msPutEvent(event, me.buttons, meDoubleClick,
				evMouseDown);
			msOldButtons &= ~me.buttons;
		}
	}
	if (me.type & (GPM_DRAG | GPM_MOVE) && event.mouse.where != msWhere)
	{
		/*
		 * Each bit set in me.buttons means the relative button is
		 * down.
		 */
		msAutoTimer.stop();
		msPutEvent(event, me.buttons, meMouseMoved, evMouseMove);
		msOldButtons = me.buttons;

		/* redraw the mouse in the new place */

		TScreen::drawMouse(0);
		msWhere = event.mouse.where;
		TScreen::drawMouse(1);
	}
	if (me.type & GPM_DOWN)
	{
		/*
		 * Each bit in me.buttons reports the actual state of the
		 * relative button.  We need to determine which button was
		 * pressed.
		 */
		msAutoTimer.start(DELAY_AUTOCLICK_FIRST);
		msPutEvent(event, me.buttons & ~msOldButtons, 0, evMouseDown);
		msOldButtons = me.buttons;
	}
	if (me.type & GPM_UP)
	{
		/*
		 * Each bit set in mev.buttons means the relative button was
		 * released.
		 */
		msAutoTimer.stop();
		msPutEvent(event, me.buttons, 0, evMouseUp);
		msOldButtons &= ~me.buttons;
	}
}
#endif

/*
 * VCS FUNCTIONS
 */

/*
 * Initializes the vcs.
 */

#ifdef __USE_VCS
static void vcsInit(char *env)
{
	vcsFd = -1;
	if (strstr(env, "novcs") != NULL) LOG("vcs support disabled");
	else
	{
		FILE *statfile;
		char path[PATH_MAX], *term;

		/*
		 * This approach was suggested by:
		 * Martynas Kunigelis <algikun@santaka.sc-uni.ktu.lt>
		 * Date: Mon, 20 Jan 1997 15:55:14 +0000 (EET)
		 */
		sprintf(path, "/proc/%d/stat", getpid());
		if ((statfile = fopen(path, "r")) != NULL)
		{
			int dev;

			/* TTYs have 4 as major number */
			/* virtual consoles have minor numbers <= 63 */

			fscanf(statfile, "%*d %*s %*c %*d %*d %*d %d", &dev);
			if ((dev & 0xff00) == 0x0400 && (dev & 0xff) <= 63)
			{
				LOG("virtual console detected");
				sprintf(path, "/dev/vcsa%d", dev & 0xff);
				if ((vcsFd = open(path, O_WRONLY)) < 0)
				{
					LOG("unable to open " << path <<
						", running in stdout mode");
				}
			}
			fclose(statfile);
		}
	}
}

/*
 * Closes the vcs device.
 */

static void vcsClose()
{
	if (vcsFd >= 0) close(vcsFd);
}
#endif

/*
 * OTHER LOCAL FUNCTIONS
 */

static void startcurses()
{
	initscr();
	keypad(stdscr, TRUE);
	cbreak();
	noecho();
	setupterm(0, STDOUT_FILENO, 0);
	timeout(0);	/* set getch() in non-blocking mode */
	TScreen::drawCursor(0);
}

static void stopcurses()
{
	/*
	 * Use the right system to clear the screen.
	 * Date: Wed, 29 Jan 1997 13:45:50 +0100 (MET)
	 */
#ifdef __USE_VCS
	if (vcsFd >= 0)		/* use vcs */
	{
		int len = TScreen::screenWidth * TScreen::screenHeight;
		ushort buf[len], *p = buf;

		while (len-- > 0) *p++ = 0x0720;	/* fill with spaces */
		lseek(vcsFd, 4, SEEK_SET);	/* home position */
		write(vcsFd, buf, sizeof(buf));
	}
	else			/* standard out */
#endif
	{
		char out[4096], *p = out;

#ifdef __FreeBSD__
		safeput(p, "[=7F");
		safeput(p, "[=0G");
#else
		safeput(p, tparm(set_foreground, 7));
		safeput(p, tparm(set_background, 0));
#endif
		safeput(p, clear_screen);
		write(STDOUT_FILENO, out, p - out);
	}
	endwin();
	echo();		/* recover previous status */
}

/*
 * Show a warning message.
 */

static int confirmExit()
{
	/* we need the buffer address */

	class MyBuffer: public TDrawBuffer
	{
	public:
		ushort *getBufAddr() { return data; }
	};
	MyBuffer b;
	static char msg[] = "Warning: are you sure you want to quit ?";

	b.moveChar(0, ' ', 0x4f, TScreen::screenWidth);
	b.moveStr(max((TScreen::screenWidth - (int) (sizeof(msg) - 1)) / 2,
		0), msg, 0x4f);
	TScreen::writeRow(TScreen::screenWidth * (TScreen::screenHeight - 1),
		b.getBufAddr(), TScreen::screenWidth);

	timeout(-1);	/* set getch() in blocking mode */
	int key = getch();
	timeout(0);	/* set getch() in non-blocking mode */
	return toupper(key) == 'Y';
}

/*
 * General signal handler.
 */

static void sigHandler(int signo)
{
	signal(signo, sigHandler);
	switch (signo)
	{
#ifdef __USE_FBSDM
	case FBSDM_SIGNAL:
		msFlag++;
		break;
#endif
	case SIGALRM:
		/*
		 * called every DELAY_SIGALRM ms
		 */
		currentTime += DELAY_SIGALRM;
		break;
	case SIGCONT:
		/*
		 * called when the user restart the process after a ctrl-z
		 */
		LOG("continuing process");
		TScreen::resume();
		signal(SIGTSTP, sigHandler);
		break;
	case SIGINT:
	case SIGQUIT:
		/*
		 * This signals are now trapped.
		 * Date: Wed, 12 Feb 1997 10:45:55 +0100 (MET)
		 */
		signal(SIGINT, SIG_IGN);
		signal(SIGQUIT, SIG_IGN);
		if (confirmExit()) exit(EXIT_FAILURE);
		doRepaint++;
		signal(SIGINT, sigHandler);
		signal(SIGQUIT, sigHandler);
		break;
	case SIGTSTP:
		/*
		 * called when the user presses ctrl-z
		 */
		TScreen::suspend();
		LOG("process stopped, type 'fg' to resume");
		signal(SIGTSTP, SIG_DFL);	/* use default handler */
		raise(SIGTSTP);		/* stop the process */
		break;
	case SIGWINCH:
		doResize++;
	}
}

/*
 * Converts colors from the large TV palette (16 foreground colors and
 * 16 background colors) to ncurses small palette (8 foreground colors
 * and 8 background colors).
 */

static void mapColor(char *&p, int col)
{
	static char map[] = {0, 4, 2, 6, 1, 5, 3, 7};
	int back = (col >> 4) & 7;
	int fore = col & 7;

	if (fore == back) fore = (fore + 1) & 7;	/* kludge */
	safeput(p, tparm(set_foreground, map[fore]));
	safeput(p, tparm(set_background, map[back]));
}

/*
 * Writes a block of text.
 */

static void writeBlock(int dst, int len, ushort *old, ushort *src)
{
	char out[4096], *p = out;
	int col = -1;

#ifdef __SAVECURSOR_OK
	safeput(p, save_cursor);
#endif
	safeput(p, tparm(cursor_address, dst / TScreen::screenWidth,
		dst % TScreen::screenWidth));
	while (len-- > 0)
	{
		int code = *src & 0xff;
		int newcol = *src >> 8;

		*old++ = *src++;
		if (col == -1 || col != newcol)	/* change color ? */
		{
			col = newcol;
			if (palette == PAL_HIGH)
			{
#ifdef __FreeBSD__
				safeput(p, tparm("[=%dF", col & 0xf));
				safeput(p, tparm("[=%dG", col >> 4));
#endif
			}
			else if (palette == PAL_LOW) mapColor(p, col);
			else if (palette == PAL_MONO)
			{
				safeput(p, exit_attribute_mode);
				if (col == 0x0f) safeput(p, enter_bold_mode);
				else if (col == 0x70)
					safeput(p, enter_reverse_mode);
			}
		}
#ifdef __FreeBSD__
		if (!usePcChars || code < ' ') code = pcToAscii[code];
#else
		code = pcToAscii[code];
#endif
		*p++ = code;
	}
#ifdef __SAVECURSOR_OK
	safeput(p, restore_cursor);
#else
	safeput(p, tparm(cursor_address, curY, curX));
#endif
	if (palette == PAL_MONO) safeput(p, exit_attribute_mode);
	write(STDOUT_FILENO, out, p - out);
}

/*
 * Select the best palette we can use.
 */

static void selectPalette()
{
#ifdef __FreeBSD__
	char *t = getenv("TERM");
	if (t != NULL && strcmp(t, "cons25") == 0)	/* best choice */
	{
		palette = PAL_HIGH;
		TScreen::screenMode = TScreen::smCO80;
		usePcChars = 1;
	}
	else if (has_colors())	/* middle choice */
	{
		palette = PAL_LOW;
		TScreen::screenMode = TScreen::smCO80;
		usePcChars = 0;
	}
	else	/* last resort */
	{
		palette = PAL_MONO;
		TScreen::screenMode = TScreen::smMono;
		usePcChars = 0;
	}
#elif defined(__linux__)
#ifdef __USE_VCS
	if (vcsFd >= 0)		/* best choice */
	{
		palette = PAL_HIGH;
		TScreen::screenMode = TScreen::smCO80;
	}
	else
#endif
	if (has_colors())	/* middle choice */
	{
		palette = PAL_LOW;
		TScreen::screenMode = TScreen::smCO80;
	}
	else	/* last resort */
	{
		palette = PAL_MONO;
		TScreen::screenMode = TScreen::smMono;
	}
#else
	if (has_colors())	/* best choice */
	{
		palette = PAL_LOW;
		TScreen::screenMode()= TScreen::smCO80;
	}
	else	/* last resort */
	{
		palette = PAL_MONO;
		TScreen::screenMode = TScreen::smMono;
	}
#endif
}

/*
 * CLASS FUNCTIONS
 */

/*
 * TScreen constructor.
 */

TScreen::TScreen()
{
	/*
	 * ESC ] Ps ND string NP
	 *	ND can be any non-digit Character (it's discarded)
	 *	NP can be any non-printing Character (it's discarded)
	 *	string can be any ASCII printable string (max 511 characters)
	 *	Ps = 0 -> use string as a new icon name and title
	 *	Ps = 1 -> use string is a new icon name only
	 *	Ps = 2 -> use string is a new title only
	 *	Ps = 46 -> use string as a new log file name
	 */
	if (getenv("DISPLAY") != NULL) cout << "\033]2;TurboVision\007";

	/*
	 * Environment variable support.
	 * Date: Wed, 29 Jan 1997 16:51:40 +0100 (MET)
	 */
	char env[PATH_MAX] = "", *p;
	if ((p = getenv("TVOPT")) != NULL)
	{
		LOG("environment variable TVOPT=" << p);
		for (char *d = env; *p != '\0'; p++) *d++ = tolower(*p);
	}

	/* acquire screen size */

	winsize win;
	ioctl(STDIN_FILENO, TIOCGWINSZ, &win);
	if (win.ws_col > 0 && win.ws_row > 0)
	{
		screenWidth = win.ws_col;
		screenHeight = win.ws_row;
	}
	else
	{
		LOG("unable to detect screen size");
		screenWidth = 80;
		screenHeight = 25;
	}
#ifdef __FreeBSD__
	/*
	 * Kludge: until we find a right way to fix the "last-line" display
	 * problem, this is a solution.
	 */
	screenHeight--;
#endif
	LOG("screen size is " << (int) screenWidth << "x" <<
		(int) screenHeight);
	screenBuffer = new ushort[screenWidth * screenHeight];

	/* setup file descriptors */

	FD_ZERO(&fdSet);
	FD_SET(STDIN_FILENO, &fdSet);

	startcurses();		/* curses stuff */
#ifdef __USE_FBSDM
	fbsdmInit(env);
#endif
#ifdef __USE_GPM
	gpmInit(env);
#endif
#ifdef __USE_VCS
	vcsInit(env);
#endif
	selectPalette();	/* select the appropiate palette */
	drawMouse(1);

	/* internal stuff */

	currentTime = doRepaint = doResize = evLength = 0;
	evIn = evOut = &evQueue[0];
	kbEscTimer.stop();
	wakeupTimer.start(DELAY_WAKEUP);

	/* catch useful signals */

#ifdef __USE_FBSDM
	signal(FBSDM_SIGNAL, sigHandler);
#endif
	signal(SIGALRM, sigHandler);
	signal(SIGCONT, sigHandler);
	signal(SIGINT, sigHandler);
	signal(SIGQUIT, sigHandler);
	signal(SIGTSTP, sigHandler);
	signal(SIGWINCH, sigHandler);

	/* generates a SIGALRM signal every DELAY_SIGALRM ms */

	struct itimerval timer;
	timer.it_interval.tv_usec = timer.it_value.tv_usec =
		DELAY_SIGALRM * 1000;
	timer.it_interval.tv_sec = timer.it_value.tv_sec = 0;
	setitimer(ITIMER_REAL, &timer, NULL);
}

/*
 * TScreen destructor.
 */

TScreen::~TScreen()
{
	drawMouse(0);
#ifdef __USE_FBSDM
	fbsdmClose();
#endif
#ifdef __USE_GPM
	gpmClose();
#endif
#ifdef __USE_VCS
	vcsClose();
#endif
	stopcurses();
	delete[] screenBuffer;
	LOG("terminated");
	if (getenv("DISPLAY") != NULL)
		cout << "\033]2;Thank you for using TurboVision\007";
}

void TScreen::resume()
{
	startcurses();
	doRepaint++;
}

void TScreen::suspend()
{
	stopcurses();
}

/*
 * Gets an event from the queue.
 */

void TScreen::getEvent(TEvent &event)
{
	event.what = evNothing;
	if (evLength > 0)	/* handles pending events */
	{
		evLength--;
		event = *evOut;
		if (++evOut >= &evQueue[QUEUE_LEN]) evOut = &evQueue[0];
	}
	else if (doRepaint)
	{
		doRepaint = 0;
		event.message.command = cmSysRepaint;
		event.what = evCommand;

		/* invalidate video buffer */

		memset(screenBuffer, 0, screenWidth * screenHeight *
			sizeof(ushort));
	}
	else if (doResize)
	{
		winsize win;

		doResize = 0;
		ioctl(STDIN_FILENO, TIOCGWINSZ, &win);
		screenWidth = range(win.ws_col, 4, 132);
		screenHeight = range(win.ws_row, 4, 80);
		delete[] screenBuffer;
		screenBuffer = new ushort[screenWidth * screenHeight];
		event.message.command = cmSysResize;
		event.what = evCommand;

		/* invalidate video buffer */

		memset(screenBuffer, 0, screenWidth * screenHeight *
			sizeof(ushort));
	}
#ifdef __USE_FBSDM
	else if (msFlag > 0)
	{
		msFlag--;
		fbsdmHandle();
	}
#endif
#if defined(__USE_FBSDM) || defined(__USE_GPM)
	else if (msAutoTimer.isExpired())
	{
		/*
		 * Now evMouseAuto works well.
		 * Date: Tue, 28 Jan 1997 19:35:31 +0100 (MET)
		 */
		msAutoTimer.start(DELAY_AUTOCLICK_NEXT);
		event.mouse.buttons = msOldButtons;
		event.mouse.where = msWhere;
		event.what = evMouseAuto;
	}
#endif
	else if (wakeupTimer.isExpired())
	{
		wakeupTimer.start(DELAY_WAKEUP);
		event.message.command = cmSysWakeup;
		event.what = evCommand;
	}
	else
	{
		fd_set ready = fdSet;
		int kbReady = 0;

		/*
		 * suspend until there is a signal or some data in file
		 * descriptors
		 */
		if (select(FD_SETSIZE, &ready, NULL, NULL, NULL) > 0)
		{
			kbReady = FD_ISSET(STDIN_FILENO, &ready);
#ifdef __USE_GPM
			if (msFd >= 0 && FD_ISSET(msFd, &ready)) gpmHandle();
#endif
		}
		if (kbReady || kbEscTimer.isRunning()) kbHandle();
	}
}

/*
 * Generates a beep.
 */

void TScreen::makeBeep()
{
	char out[4096], *p = out;

	safeput(p, bell);
	write(STDOUT_FILENO, out, p - out);
}

/*
 * Puts an event in the queue.  If the queue is full the event will be
 * discarded.
 */

void TScreen::putEvent(TEvent &event)
{
	if (evLength < QUEUE_LEN)
	{
		evLength++;
		*evIn = event;
		if (++evIn >= &evQueue[QUEUE_LEN]) evIn = &evQueue[0];
	}
}

/*
 * Hides or shows the cursor.
 */

void TScreen::drawCursor(int show)
{
	/*
	 * 'Hides' the cursor by moving it in the lower right corner
	 * of the screen.
	 * Date: Wed, 12 Feb 1997 00:47:33 +0100 (MET)
	 */
	if (!show) moveCursor(screenWidth - 1, screenHeight - 1);
}

/*
 * Hides or shows the mouse pointer.
 */

void TScreen::drawMouse(int show)
{
#ifdef __USE_FBSDM
	if (msUseArrow)
	{
		mouse_info_t mi;

		mi.operation = MOUSE_HIDE;
		ioctl(STDOUT_FILENO, CONS_MOUSECTL, &mi);
		if (show)
		{
			mi.operation = MOUSE_SHOW;
			ioctl(STDOUT_FILENO, CONS_MOUSECTL, &mi);
		}
	}
	else
#endif
	{
#ifdef __USE_GPM
		if (msFd < 0) return;
#endif
		int addr = screenWidth * msWhere.y + msWhere.x;
		ushort cell = screenBuffer[addr];
#ifdef __USE_VCS
		if (vcsFd >= 0)		/* use vcs */
		{
			if (show) cell ^= 0x7f00;
			lseek(vcsFd, addr * sizeof(ushort) + 4, SEEK_SET);
			write(vcsFd, &cell, sizeof(ushort));
		}
		else			/* standard out */
#endif
		{
			char out[4096], *p = out;
			int code = cell & 0xff;
			int col = cell >> 8;

#ifdef __SAVECURSOR_OK
			safeput(p, save_cursor);
#endif
			safeput(p, tparm(cursor_address, msWhere.y,
				msWhere.x));
			if (palette == PAL_HIGH)
			{
				if (show) col ^= 0x7f;
#ifdef __FreeBSD__
				safeput(p, tparm("[=%dF", col & 0xf));
				safeput(p, tparm("[=%dG", col >> 4));
#endif
			}
			else if (palette == PAL_LOW)
			{
				if (show) col ^= 0x7f;
				mapColor(p, col);
			}
			else if (palette == PAL_MONO)
			{
				if (show)
				{
					if (col == 0x0f || col == 0x07)
						safeput(p,
						enter_reverse_mode);
				}
				else
				{
					if (col == 0x0f) safeput(p,
						enter_bold_mode);
					else if (col == 0x70) safeput(p,
						enter_reverse_mode);
				}
			}
#ifdef __FreeBSD__
			if (!usePcChars || code < ' ') code = pcToAscii[code];
#else
			code = pcToAscii[code];
#endif
			*p++ = code;
#ifdef __SAVECURSOR_OK
			safeput(p, restore_cursor);
#else
			safeput(p, tparm(cursor_address, curY, curX));
#endif
			if (palette == PAL_MONO) safeput(p,
				exit_attribute_mode);
			write(STDOUT_FILENO, out, p - out);
		}
	}
}

/*
 * Moves the cursor to another place.
 */

void TScreen::moveCursor(int x, int y)
{
#ifdef __USE_VCS
	if (vcsFd >= 0)		/* use vcs */
	{
		unsigned char where[2] = {x, y};

		lseek(vcsFd, 2, SEEK_SET);
		write(vcsFd, where, sizeof(where));
	}
	else			/* standard out */
#endif
	{
		char out[4096], *p = out;

		safeput(p, tparm(cursor_address, y, x));
		write(STDOUT_FILENO, out, p - out);
#ifndef __SAVECURSOR_OK
		curX = x;
		curY = y;
#endif
	}
}

/*
 * Draws a line of text on the screen.
 */

void TScreen::writeRow(int dst, ushort *src, int len)
{
#ifdef __USE_VCS
	if (vcsFd >= 0)		/* use vcs */
	{
		lseek(vcsFd, dst * sizeof(ushort) + 4, SEEK_SET);
		write(vcsFd, src, len * sizeof(ushort));
	}
	else			/* standard out */
#endif
	{
		ushort *old = screenBuffer + dst;
		ushort *old_right = old + len - 1;
		ushort *src_right = src + len - 1;

		/* remove unchanged characters from left to right */

		while (len > 0 && *old == *src)
		{
			dst++;
			len--;
			old++;
			src++;
		}

		/* remove unchanged characters from right to left */

		while (len > 0 && *old_right == *src_right)
		{
			len--;
			old_right--;
			src_right--;
		}

		/* write only middle changed characters */

		if (len > 0) writeBlock(dst, len, old, src);
	}
}

/*
 * Returns the length of a file.
 */

long int filelength(int fd)
{
	long int save = lseek(fd, 0, SEEK_CUR);
	long int len = lseek(fd, 0, SEEK_END);

	lseek(fd, save, SEEK_SET);
	return len;
}

/*
 * Expands a path into its directory and file components.
 */

void expandPath(const char *path, char *dir, char *file)
{
	char *tag = strrchr(path, '/');

	/* the path is in the form /dir1/dir2/file ? */

	if (tag != NULL)
	{
		strcpy(file, tag + 1);
		strncpy(dir, path, tag - path + 1);
		dir[tag - path + 1] = '\0';
	}
	else
	{
		/* there is only the file name */

		strcpy(file, path);
		dir[0] = '\0';
	}
}

void fexpand(char *path)
{
	char dir[PATH_MAX];
	char file[PATH_MAX];
	char oldPath[PATH_MAX];

	expandPath(path, dir, file);
	getcwd(oldPath, sizeof(oldPath));
	chdir(dir);
	getcwd(dir, sizeof(dir));
	chdir(oldPath);
	if (strcmp(dir, "/") == 0) sprintf(path, "/%s", file);
	else sprintf(path, "%s/%s", dir, file);
}
